// src/App.jsx
import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, Outlet } from "react-router-dom";
import { Menu } from "lucide-react"; // Import Menu icon for the hamburger button
import logo from "../src/assets/Logo.png"

import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import UploadHerbData from "./pages/UploadHerbData";
import MyBatches from "./pages/MyBatches";
import ScanUpdateBatch from "./pages/ScanUpdateBatch";
import ProcessScanUpdateBatch from "./pages/processScanUpdatePage";
import LabScanUpdateBatch from "./pages/LabScanUpdateBatch";
import ManufactureScanUpdatePage from "./pages/ManufactureScanUpdatePage ";
import HerbDetails from "./components/HerbDetailsfinal";
import SignIn from "./pages/SignIn";
import Home from "./pages/Home";
import Signup from "./pages/Signup";
import ConsumerPage from "./pages/ConsumerPage.jsx";
import "./i18n.js";

// --- Role-based protected route wrapper (no changes needed here) ---
const RoleProtectedRoute = ({ allowedRoles, children }) => {
  const storedUser = localStorage.getItem("user");
  const user = storedUser ? JSON.parse(storedUser) : null;
  const location = useLocation();

  if (!user) {
    return <Navigate to="/signin" state={{ from: location }} replace />;
  }
  if (!allowedRoles.includes(user.role)) {
    // Redirect unauthorized users back to their dashboard
    return <Navigate to="/dashboard" replace />;
  }
  return children;
};

// ✅ 1. Create a new AppLayout component to manage sidebar state and page content
const AppLayout = ({ user, onSignOut }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  if (!user) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar
        user={user}
        onSignOut={onSignOut}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main content */}
      <main className="transition-all duration-300 ease-in-out md:ml-64">
        {/* ✅ Header with Hamburger button (only visible on mobile) */}
        <header className="flex items-center justify-between bg-white shadow-md h-16 px-4 md:hidden">
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="p-2 rounded-md hover:bg-gray-100 focus:outline-none"
          >
            <Menu size={28} />
          </button>
          <h1><div className="flex-shrink-0">
                                <img src={logo} alt="Sanjeevani Logo" className="  h-12 w-auto" />
                              </div></h1>
        </header>

        {/* Page Content */}
        <div className="p-4 lg:p-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
};


// --- Main App Component ---
function App() {
  const [user, setUser] = useState(() => {
    const storedUser = localStorage.getItem("user");
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const handleSignOut = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  const handleSignIn = (userData) => {
    setUser(userData);
    localStorage.setItem("user", JSON.stringify(userData));
  };

  return (
    <Router>
      <Routes>
        {/* --- Public Routes --- */}
        <Route path="/" element={user ? <Navigate to="/dashboard" /> : <Home />} />
        <Route path="/signin" element={user ? <Navigate to="/dashboard" /> : <SignIn onSignIn={handleSignIn} />} />
        <Route path="/signup" element={user ? <Navigate to="/dashboard" /> : <Signup />} />
        <Route path="/consumer/:id" element={<ConsumerPage />} />

        {/* ✅ 2. Use a single parent layout route for all protected pages */}
        <Route element={<AppLayout user={user} onSignOut={handleSignOut} />}>
          <Route path="/dashboard" element={<Dashboard user={user} />} />
          <Route path="/my-batches" element={<MyBatches user={user} />} />
          <Route path="/scan-update-batch" element={<ScanUpdateBatch user={user} />} />
          <Route path="/processscan-update-batch" element={<ProcessScanUpdateBatch user={user} />} />
          <Route path="/labscan-update-batch" element={<LabScanUpdateBatch user={user} />} />
          <Route path="/manufacturerscan-update-batch" element={<ManufactureScanUpdatePage user={user} />} />

          {/* Role Protected Routes */}
          <Route
            path="/upload-herb-data"
            element={
              <RoleProtectedRoute allowedRoles={["farmer"]}>
                <UploadHerbData user={user} />
              </RoleProtectedRoute>
            }
          />
          <Route
            path="/:hash"
            element={
              <RoleProtectedRoute allowedRoles={["farmer", "distributor"]}>
                <HerbDetails />
              </RoleProtectedRoute>
            }
          />
        </Route>

        {/* --- Catch-all Route --- */}
        <Route path="*" element={<Navigate to={user ? "/dashboard" : "/"} replace />} />
      </Routes>
    </Router>
  );
}

export default App;