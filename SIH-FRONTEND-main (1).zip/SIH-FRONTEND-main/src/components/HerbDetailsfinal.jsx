import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const API = import.meta.env.VITE_API_BASE_URL;

const HerbDetails = () => {
  const { hash } = useParams();
  const [block, setBlock] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchHerb = async () => {
      try {
        const res = await fetch(`${API}/api/block/${hash}`);
        if (!res.ok) throw new Error("Failed to fetch herb");
        const data = await res.json();
        setBlock(data.block);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchHerb();
  }, [hash]);

  if (loading) return <p className="text-center">⏳ Loading...</p>;
  if (error) return <p className="text-center text-red-500">❌ {error}</p>;

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
      <div className="bg-white shadow-lg rounded-2xl p-6 max-w-lg w-full">
        <h1 className="text-2xl font-bold text-green-700 mb-4">
          🌿 Herb Batch Details
        </h1>

        <div className="space-y-2">
          <p><b>Herb Name:</b> {block?.data?.herbName}</p>
          <p><b>Date:</b> {block?.data?.date}</p>
          <p><b>Quantity:</b> {block?.data?.quantity}</p>
          <p><b>Farmer ID:</b> {block?.data?.farmerId}</p>
          <p>
            <b>Geo Location:</b> {block?.data?.geoLocation?.lat},{" "}
            {block?.data?.geoLocation?.long}
          </p>
        </div>

        <hr className="my-4" />

        <h2 className="text-lg font-semibold text-gray-700">🧾 Blockchain Info</h2>
        <p><b>Block Index:</b> {block?.index}</p>
        <p><b>Block Hash:</b> <span className="break-all">{block?.hash}</span></p>
        <p><b>Previous Hash:</b> <span className="break-all">{block?.previousHash}</span></p>
        <p><b>Timestamp:</b> {block?.timestamp ? new Date(block.timestamp).toLocaleString() : ""}</p>
      </div>
    </div>
  );
};

export default HerbDetails;
