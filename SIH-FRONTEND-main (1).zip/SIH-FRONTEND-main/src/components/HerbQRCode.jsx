import React from "react";
import QRCode from "qrcode.react";

const HerbQRCode = ({ response }) => {
  // Extract the block/herb object
  const qrData = {
    herbName: response?.herb?.herbName,
    date: response?.herb?.date,
    quantity: response?.herb?.quantity,
    geoLocation: response?.herb?.geoLocation,
    farmerId: response?.herb?.farmer,
    hash: response?.hash,
    previousHash: response?.previousHash,
    index: response?.index,
    timestamp: response?.timestamp,
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <h2 className="text-xl font-semibold">Herb QR Code</h2>

      {/* Generate QR with JSON.stringify */}
      <QRCode
        value={JSON.stringify(qrData)}
        size={200}
        level="H"
        includeMargin={true}
      />

      <pre className="bg-gray-100 p-3 rounded-lg text-sm max-w-md overflow-x-auto">
        {JSON.stringify(qrData, null, 2)}
      </pre>
    </div>
  );
};

export default HerbQRCode;
