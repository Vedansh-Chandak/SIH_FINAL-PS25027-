// src/components/Navbar.jsx
import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";

const Navbar = ({ user, onSignOut, language, toggleLanguage }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const navigate = useNavigate();
  const userMenuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setIsUserMenuOpen(false);
      }
    };

    if (isUserMenuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isUserMenuOpen]);

  const getInitials = (name) => {
    if (!name) return "?";
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name[0].toUpperCase();
  };

  return (
    <header className="sticky top-0 z-50">
      <nav className="bg-[#133215] text-white px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center shadow-lg">

        {/* Logo */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate("/")}>
          <h1 className="text-2xl font-bold tracking-wider">Sanjeevani</h1>
        </div>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center gap-4">

          {/* 🔥 LANGUAGE SWITCH */}
          <button
            onClick={toggleLanguage}
            className="px-3 py-1 text-sm bg-transparent border border-white rounded-md hover:bg-white hover:text-[#133215] transition"
          >
            {language === "en" ? "हिन्दी" : "English"}
          </button>

          {user ? (
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-3 cursor-pointer p-1 rounded-full hover:bg-white/10 transition"
              >
                <div className="w-9 h-9 rounded-full bg-[#92B775] flex items-center justify-center text-[#133215] font-bold text-sm">
                  {getInitials(user.name)}
                </div>

                <div className="text-left">
                  <div className="font-semibold text-sm">{user.name}</div>
                  <div className="text-xs text-gray-300 capitalize">{user.role}</div>
                </div>
              </button>

              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 text-black z-50">
                  <button
                    onClick={onSignOut}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => navigate("/signin")}
              className="px-4 py-2 text-sm bg-[#92B775] text-[#133215] font-bold rounded-md hover:bg-[#a7c989]"
            >
              Login / Signup
            </button>
          )}
        </div>

        {/* Hamburger */}
        <button
          className="md:hidden text-2xl"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? "✖" : "☰"}
        </button>
      </nav>

      {/* Mobile dropdown */}
      <div className={`md:hidden bg-[#133215] text-white ${isMenuOpen ? "" : "hidden"} pb-6`}>
        
        {/* Mobile lang switch */}
        <button
          onClick={toggleLanguage}
          className="block w-full px-4 py-3 text-center bg-white/10 hover:bg-white/20"
        >
          {language === "en" ? "हिन्दी" : "English"}
        </button>

        {!user ? (
          <button
            onClick={() => navigate("/signin")}
            className="w-full px-4 py-2 mt-4 bg-[#92B775] text-[#133215] rounded-md"
          >
            Login / Signup
          </button>
        ) : (
          <button
            onClick={onSignOut}
            className="w-full px-4 py-3 mt-4 bg-red-600 rounded-md"
          >
            Logout
          </button>
        )}
      </div>
    </header>
  );
};

export default Navbar;
