// // // src/components/Sidebar.js
// // import React from "react";
// // import { NavLink } from "react-router-dom";
// // import logo from  "../assets/Logo.png"
// // import {
// //   LayoutDashboard,
// //   Leaf,
// //   Package,
// //   LogOut,
// //   User,
// //   FlaskConical,
// //   Microscope,
// //   Factory,
// //   Truck,
// //   X, // Import the close icon
// // } from "lucide-react";

// // // --- Navigation Links Configuration ---
// // // We define all possible links here to easily manage them.
// // // The `roles` array determines which user roles can see each link.
// // const mainLinks = [
// //   { to: "/dashboard", icon: LayoutDashboard, text: "Home", roles: ["farmer", "transporter", "processor", "lab", "manufacturer"] },
// //   { to: "/upload-herb-data", icon: Leaf, text: "Upload new Herb", roles: ["farmer"] },
// //   { to: "/my-batches", icon: Package, text: "My Harvest", roles: ["farmer"] },
// // ];

// // const scanUpdateLinks = [
// //   { to: "/scan-update-batch", icon: Truck, text: "Transport Logistics", roles: [ "transporter"] },
// //   { to: "/processscan-update-batch", icon: FlaskConical, text: "Processing Unit", roles: ["processor"] },
// //   { to: "/labscan-update-batch", icon: Microscope, text: "Lab", roles: ["lab"] },
// //   { to: "/manufacturerscan-update-batch", icon: Factory, text: "Manufacturer", roles: ["manufacturer"] },
// // ];

// // // Helper function for NavLink classes
// // const getNavLinkClass = ({ isActive }) =>
// //   `relative flex items-center gap-4 p-3 rounded-lg transition-colors duration-200 ${
// //     isActive
// //       ? "bg-[#1a431d] text-white"
// //       : "text-gray-300 hover:bg-[#1a431d]/75 hover:text-white"
// //   }`;

// // // --- The Sidebar Component ---
// // const Sidebar = ({ user, onSignOut, isOpen, onClose }) => {
// //   // Filter links based on the current user's role
// //   const userRole = user?.role?.toLowerCase() || "";
// //   const visibleMainLinks = mainLinks.filter(link => link.roles.includes(userRole));
// //   const visibleScanLinks = scanUpdateLinks.filter(link => link.roles.includes(userRole));

// //   const NavLinkItem = ({ to, icon: Icon, text }) => (
// //     <NavLink to={to} className={getNavLinkClass} onClick={onClose}>
// //       {({ isActive }) => (
// //         <>
// //           {isActive && <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />}
// //           <Icon size={22} />
// //           <span>{text}</span>
// //         </>
// //       )}
// //     </NavLink>
// //   );

// //   return (
// //     <>
// //       {/* --- Backdrop for Mobile --- */}
// //       <div
// //         onClick={onClose}
// //         className={`fixed inset-0 bg-black/60 z-20 md:hidden transition-opacity ${
// //           isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
// //         }`}
// //         aria-hidden="true"
// //       />

// //       {/* --- Main Sidebar Container --- */}
// //       <aside
// //         className={`w-64 h-screen bg-[#133215] text-white flex flex-col fixed top-0 left-0 z-30 shadow-2xl 
// //                    transition-transform duration-300 ease-in-out 
// //                    md:translate-x-0 ${isOpen ? "translate-x-0" : "-translate-x-full"}`}
// //       >
// //         {/* --- Header (App Logo & Close Button) --- */}
// //         <div className="flex items-center justify-between p-4 border-b border-white/10 h-20">
// //            <div className="flex-shrink-0">
// //                       <img src={logo} alt="Sanjeevani Logo" className="  h-12 w-auto" />
// //                     </div>
// //           {/* Close button for mobile */}
// //           <button onClick={onClose} className="p-1 md:hidden rounded-full hover:bg-white/10">
// //             <X size={24} />
// //           </button>
// //         </div>

// //         {/* --- User Info Section --- */}
// //         {user && (
// //           <div className="p-4 border-b border-white/10 flex items-center gap-4">
// //             <User size={36} className="p-1.5 bg-black/20 rounded-full flex-shrink-0" />
// //             <div className="overflow-hidden">
// //               <p className="font-semibold text-sm truncate" title={user.name}>{user.name}</p>
// //               <p className="text-xs text-gray-400 capitalize">{user.role}</p>
// //             </div>
// //           </div>
// //         )}

// //         {/* --- Main container to push logout to the bottom --- */}
// //         <div className="flex flex-col justify-between flex-1">
// //           {/* --- Navigation Menu --- */}
// //           <nav className="flex-1 p-4 space-y-2">
// //             {visibleMainLinks.map(link => <NavLinkItem key={link.to} {...link} />)}

// //             {/* Conditionally render the "Scan & Update" heading */}
// //             {visibleScanLinks.length > 0 && (
// //               <p className="pt-4 pb-1 px-3 text-xs text-gray-400 font-semibold uppercase">Scan & Update</p>
// //             )}

// //             {visibleScanLinks.map(link => <NavLinkItem key={link.to} {...link} />)}
// //           </nav>

// //           {/* --- Footer (Logout) --- */}
// //           <div className="p-4 border-t border-white/10">
// //             <button
// //               onClick={onSignOut}
// //               className="flex items-center w-full gap-4 p-3 rounded-lg transition-colors duration-200 text-gray-300 hover:bg-[#1a431d]/75  hover:text-white"
// //             >
// //               <LogOut size={22} />
// //               <span className="font-medium">Logout</span>
// //             </button>
// //           </div>
// //         </div>
// //       </aside>
// //     </>
// //   );
// // };

// // export default Sidebar;

// // src/components/Sidebar.js
// import React from "react";
// import { NavLink } from "react-router-dom";
// import logo from "../assets/Logo.png";
// import {
//   LayoutDashboard,
//   Leaf,
//   Package,
//   LogOut,
//   User,
//   FlaskConical,
//   Microscope,
//   Factory,
//   Truck,
//   X,
// } from "lucide-react";

// // ------------------------------
// //  LANGUAGE: default Hindi
// // ------------------------------
// const language = "hi";  // <-- change to "en" if needed later

// // ------------------------------
// // Navigation links
// // ------------------------------
// const mainLinks = [
//   { to: "/dashboard", icon: LayoutDashboard, text: { hi: "होम", en: "Home" }, roles: ["farmer", "transporter", "processor", "lab", "manufacturer"] },
//   { to: "/upload-herb-data", icon: Leaf, text: { hi: "नया हर्ब अपलोड", en: "Upload new Herb" }, roles: ["farmer"] },
//   { to: "/my-batches", icon: Package, text: { hi: "मेरी फसल", en: "My Harvest" }, roles: ["farmer"] },
// ];

// const scanUpdateLinks = [
//   { to: "/scan-update-batch", icon: Truck, text: { hi: "परिवहन", en: "Transport Logistics" }, roles: ["transporter"] },
//   { to: "/processscan-update-batch", icon: FlaskConical, text: { hi: "प्रोसेसिंग यूनिट", en: "Processing Unit" }, roles: ["processor"] },
//   { to: "/labscan-update-batch", icon: Microscope, text: { hi: "प्रयोगशाला", en: "Lab" }, roles: ["lab"] },
//   { to: "/manufacturerscan-update-batch", icon: Factory, text: { hi: "निर्माता", en: "Manufacturer" }, roles: ["manufacturer"] },
// ];

// // NavLink style
// const getNavLinkClass = ({ isActive }) =>
//   `relative flex items-center gap-4 p-3 rounded-lg transition-colors duration-200 ${
//     isActive
//       ? "bg-[#1a431d] text-white"
//       : "text-gray-300 hover:bg-[#1a431d]/75 hover:text-white"
//   }`;

// const Sidebar = ({ user, onSignOut, isOpen, onClose }) => {
//   const userRole = user?.role?.toLowerCase() || "";
//   const visibleMainLinks = mainLinks.filter(l => l.roles.includes(userRole));
//   const visibleScanLinks = scanUpdateLinks.filter(l => l.roles.includes(userRole));

//   const NavLinkItem = ({ to, icon: Icon, text }) => (
//     <NavLink to={to} className={getNavLinkClass} onClick={onClose}>
//       {({ isActive }) => (
//         <>
//           {isActive && (
//             <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />
//           )}
//           <Icon size={22} />
//           <span>{text[language]}</span>
//         </>
//       )}
//     </NavLink>
//   );

//   return (
//     <>
//       <div
//         onClick={onClose}
//         className={`fixed inset-0 bg-black/60 z-20 md:hidden transition-opacity ${
//           isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
//         }`}
//         aria-hidden="true"
//       />

//       <aside
//         className={`w-64 h-screen bg-[#133215] text-white flex flex-col fixed top-0 left-0 z-30 shadow-2xl 
//           transition-transform duration-300 ease-in-out 
//           md:translate-x-0 ${isOpen ? "translate-x-0" : "-translate-x-full"}`}
//       >
//         {/* Header */}
//         <div className="flex items-center justify-between p-4 border-b border-white/10 h-20">
//           <div>
//             <img src={logo} alt="Sanjeevani Logo" className="h-12 w-auto" />
//           </div>
//           <button onClick={onClose} className="p-1 md:hidden rounded-full hover:bg-white/10">
//             <X size={24} />
//           </button>
//         </div>

//         {/* User info */}
//         {user && (
//           <div className="p-4 border-b border-white/10 flex items-center gap-4">
//             <User size={36} className="p-1.5 bg-black/20 rounded-full" />
//             <div className="overflow-hidden">
//               <p className="font-semibold text-sm truncate">{user.name}</p>
//               <p className="text-xs text-gray-400 capitalize">{user.role}</p>
//             </div>
//           </div>
//         )}

//         <div className="flex flex-col justify-between flex-1">
//           {/* Menu */}
//           <nav className="flex-1 p-4 space-y-2">
//             {visibleMainLinks.map(link => (
//               <NavLinkItem key={link.to} {...link} />
//             ))}

//             {visibleScanLinks.length > 0 && (
//               <p className="pt-4 pb-1 px-3 text-xs text-gray-400 font-semibold uppercase">
//                 {language === "hi" ? "स्कैन और अपडेट" : "Scan & Update"}
//               </p>
//             )}

//             {visibleScanLinks.map(link => (
//               <NavLinkItem key={link.to} {...link} />
//             ))}
//           </nav>

//           {/* Logout */}
//           <div className="p-4 border-t border-white/10">
//             <button
//               onClick={onSignOut}
//               className="flex items-center w-full gap-4 p-3 rounded-lg transition-colors duration-200 text-gray-300 hover:bg-[#1a431d]/75 hover:text-white"
//             >
//               <LogOut size={22} />
//               <span>{language === "hi" ? "लॉग आउट" : "Logout"}</span>
//             </button>
//           </div>
//         </div>
//       </aside>
//     </>
//   );
// };

// export default Sidebar;


// src/components/Sidebar.js
import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import logo from "../assets/Logo.png";
import {
  LayoutDashboard,
  Leaf,
  Package,
  LogOut,
  User,
  FlaskConical,
  Microscope,
  Factory,
  Truck,
  X,
} from "lucide-react";

// ------------------------------
// Links
// ------------------------------
const mainLinks = [
  { to: "/dashboard", icon: LayoutDashboard, text: { hi: "होम", en: "Home" }, roles: ["farmer", "transporter", "processor", "lab", "manufacturer"] },
  { to: "/upload-herb-data", icon: Leaf, text: { hi: "नया हर्ब अपलोड", en: "Upload new Herb" }, roles: ["farmer"] },
  { to: "/my-batches", icon: Package, text: { hi: "मेरी फसल", en: "My Harvest" }, roles: ["farmer"] },
];

const scanUpdateLinks = [
  { to: "/scan-update-batch", icon: Truck, text: { hi: "परिवहन", en: "Transport Logistics" }, roles: ["transporter"] },
  { to: "/processscan-update-batch", icon: FlaskConical, text: { hi: "प्रोसेसिंग यूनिट", en: "Processing Unit" }, roles: ["processor"] },
  { to: "/labscan-update-batch", icon: Microscope, text: { hi: "प्रयोगशाला", en: "Lab" }, roles: ["lab"] },
  { to: "/manufacturerscan-update-batch", icon: Factory, text: { hi: "निर्माता", en: "Manufacturer" }, roles: ["manufacturer"] },
];

const getNavLinkClass = ({ isActive }) =>
  `relative flex items-center gap-4 p-3 rounded-lg transition-colors duration-200 ${
    isActive
      ? "bg-[#1a431d] text-white"
      : "text-gray-300 hover:bg-[#1a431d]/75 hover:text-white"
  }`;

const Sidebar = ({ user, onSignOut, isOpen, onClose }) => {

  // 🔥 language toggle state
  const [language, setLanguage] = useState("hi");

  const toggleLanguage = () => {
    setLanguage(prev => (prev === "hi" ? "en" : "hi"));
  };

  const userRole = user?.role?.toLowerCase() || "";
  const visibleMainLinks = mainLinks.filter(l => l.roles.includes(userRole));
  const visibleScanLinks = scanUpdateLinks.filter(l => l.roles.includes(userRole));

  const NavLinkItem = ({ to, icon: Icon, text }) => (
    <NavLink to={to} className={getNavLinkClass} onClick={onClose}>
      {({ isActive }) => (
        <>
          {isActive && (
            <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />
          )}
          <Icon size={22} />
          <span>{text[language]}</span>
        </>
      )}
    </NavLink>
  );

  return (
    <>
      <div
        onClick={onClose}
        className={`fixed inset-0 bg-black/60 z-20 md:hidden transition-opacity ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        aria-hidden="true"
      />

      <aside
        className={`w-64 h-screen bg-[#133215] text-white flex flex-col fixed top-0 left-0 z-30 shadow-2xl 
          transition-transform duration-300 ease-in-out 
          md:translate-x-0 ${isOpen ? "translate-x-0" : "-translate-x-full"}`}
      >
        {/* -------- Header ---------- */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 h-20">

          {/* LOGO + LANGUAGE BUTTON */}
          <div className="flex items-center gap-2">
            <img src={logo} alt="Sanjeevani Logo" className="h-12 w-auto" />

            {/* LANGUAGE SWITCH BUTTON */}
            <button
              className="px-2 py-1 text-xs rounded bg-white/10 hover:bg-white/20"
              onClick={toggleLanguage}
            >
              {language === "hi" ? "ENG" : "हिन्दी"}
            </button>
          </div>

          {/* Close Button (mobile) */}
          <button onClick={onClose} className="p-1 md:hidden rounded-full hover:bg-white/10">
            <X size={24} />
          </button>
        </div>

        {user && (
          <div className="p-4 border-b border-white/10 flex items-center gap-4">
            <User size={36} className="p-1.5 bg-black/20 rounded-full" />
            <div>
              <p className="font-semibold text-sm">{user.name}</p>
              <p className="text-xs text-gray-400 capitalize">{user.role}</p>
            </div>
          </div>
        )}

        <div className="flex flex-col justify-between flex-1">
          <nav className="flex-1 p-4 space-y-2">
            {visibleMainLinks.map(link => (
              <NavLinkItem key={link.to} {...link} />
            ))}

            {visibleScanLinks.length > 0 && (
              <p className="pt-4 pb-1 px-3 text-xs text-gray-400 font-semibold uppercase">
                {language === "hi" ? "स्कैन और अपडेट" : "Scan & Update"}
              </p>
            )}

            {visibleScanLinks.map(link => (
              <NavLinkItem key={link.to} {...link} />
            ))}
          </nav>

          <div className="p-4 border-t border-white/10">
            <button
              onClick={onSignOut}
              className="flex items-center w-full gap-4 p-3 rounded-lg text-gray-300 hover:bg-[#1a431d]/75 hover:text-white"
            >
              <LogOut size={22} />
              <span>{language === "hi" ? "लॉग आउट" : "Logout"}</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
