// import React, { useState, useEffect, useRef, useCallback } from "react";
// import { QRCodeSVG as QRCode } from "qrcode.react";
// import { getAddressFromCoords } from "../utils/geocode";
// import { saveOfflineHerb, getOfflineHerbs, clearOfflineHerbs } from "../utils/db";

// // --- Icon Components ---
// const MicIcon = ({ isListening }) => (
//   <svg
//     xmlns="http://www.w3.org/2000/svg"
//     viewBox="0 0 24 24"
//     fill="currentColor"
//     className={`w-6 h-6 transition-colors ${isListening ? "text-red-500 animate-pulse" : "text-gray-500 hover:text-green-600"}`}
//   >
//     <path d="M8.25 4.5a3.75 3.75 0 1 1 7.5 0v8.25a3.75 3.75 0 1 1-7.5 0V4.5Z" />
//     <path d="M6 10.5a.75.75 0 0 1 .75.75v1.5a5.25 5.25 0 1 0 10.5 0v-1.5a.75.75 0 0 1 1.5 0v1.5a6.75 6.75 0 1 1-13.5 0v-1.5A.75.75 0 0 1 6 10.5Z" />
//   </svg>
// );

// const SpeakerIcon = () => (
//   <svg
//     xmlns="http://www.w3.org/2000/svg"
//     viewBox="0 0 24 24"
//     fill="currentColor"
//     className="w-7 h-7 text-gray-500 hover:text-green-600"
//   >
//     <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 0 0 1.5 12c0 .898.121 1.768.348 2.595.341 1.24 1.518 1.905 2.66 1.905H6.44l4.5 4.5c.944.945 2.56.276 2.56-1.06V4.06ZM18.584 5.106a.75.75 0 0 1 1.06 0c3.807 3.808 3.807 9.98 0 13.788a.75.75 0 0 1-1.06-1.06 8.25 8.25 0 0 0 0-11.668.75.75 0 0 1 0-1.06Z" />
//     <path d="M15.932 7.757a.75.75 0 0 1 1.061 0 6 6 0 0 1 0 8.486.75.75 0 0 1-1.06-1.061 4.5 4.5 0 0 0 0-6.364.75.75 0 0 1 0-1.06Z" />
//   </svg>
// );


// const UploadHerbDataform = () => {
//   // Helpers
//   const getTodaysDate = () => {
//     const today = new Date();
//     return today.toISOString().split("T")[0];
//   };
//   const API = import.meta.env.VITE_API_BASE_URL;
//   const FRONTEND = import.meta.env.VITE_FRONTEND;

//   // Form state
//   const [herbName, setHerbName] = useState("");
//   const [quantity, setQuantity] = useState("");
//   const [formData, setFormData] = useState({
//     date: getTodaysDate(),
//     geoLocation: { lat: null, long: null },
//     farmerId: "68c01df224a94683b890f7e1",
//   });
//   const [submittedHerb, setSubmittedHerb] = useState(null);
//   const [language, setLanguage] = useState("en");
//   const [status, setStatus] = useState("");
//   const [isSaving, setIsSaving] = useState(false);
//   const [listeningField, setListeningField] = useState(null); // 'herbName' or 'quantity'

//   // Refs
//   const hiddenQRContainerRef = useRef(null);
//   const recognitionRef = useRef(null);
//   const [qrValue, setQrValue] = useState("");

//   // Sync offline data when online
//   useEffect(() => {
//     const syncOfflineData = async () => {
//       const offlineHerbs = await getOfflineHerbs();
//       if (offlineHerbs.length === 0) return;

//       for (let herb of offlineHerbs) {
//         try {
//           const res = await fetch(`${API}/herbs`, {
//             method: "POST",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify(herb),
//           });
//           if (res.ok) console.log("✅ Synced:", herb);
//         } catch (err) {
//           console.error("❌ Sync failed:", err);
//         }
//       }
//       await clearOfflineHerbs();
//     };

//     window.addEventListener("online", syncOfflineData);
//     if (navigator.onLine) syncOfflineData();
//     return () => window.removeEventListener("online", syncOfflineData);
//   }, [API]);

//   // Cleanup speech API on unmount
//   useEffect(() => {
//     return () => {
//       window.speechSynthesis?.cancel();
//       if (recognitionRef.current) {
//         recognitionRef.current.abort();
//       }
//     };
//   }, []);

//   // Translations
//   const translations = {
//     en: {
//       formTitle: "Herb Data Upload",
//       formSubtitle: "Capture new herb data with quantities.",
//       successTitle: "Submission Successful!",
//       successSubtitle: "A unique QR code has been generated for this batch.",
//       addAnother: "Add Another Herb",
//       languageLabel: "Language",
//       herbNameLabel: "Herb Name",
//       quantityLabel: "Quantity (in grams)",
//       dateLabel: "Date",
//       latitudeLabel: "Latitude",
//       longitudeLabel: "Longitude",
//       farmerIdLabel: "Farmer ID",
//       uploadButton: "Upload Data",
//       geolocationError: "Geolocation is blocked.",
//       geolocationNotSupported: "Geolocation not supported by your browser.",
//       speechNotSupported: "Speech recognition not supported by your browser.",
//       speechError: "Speech recognition error. Please try again.",
//       speakHeader: "Speak form title",
//       stateLabel: "State",
//       countryLabel: "Country",
//       pincodeLabel: "Pincode",
//       fullAddressLabel: "Full Address",
//     },
//     hi: {
//       formTitle: "जड़ी बूटी डेटा अपलोड",
//       formSubtitle: "मात्रा के साथ नया जड़ी बूटी डेटा कैप्चर करें।",
//       successTitle: "सफलतापूर्वक सबमिट किया गया!",
//       successSubtitle: "इस बैच के लिए एक अद्वितीय क्यूआर कोड उत्पन्न किया गया है।",
//       addAnother: "एक और जड़ी बूटी जोड़ें",
//       languageLabel: "भाषा",
//       herbNameLabel: "जड़ी बूटी का नाम",
//       quantityLabel: "मात्रा (ग्राम में)",
//       dateLabel: "तारीख",
//       latitudeLabel: "अक्षांश",
//       longitudeLabel: "देशांतर",
//       farmerIdLabel: "किसान आईडी",
//       uploadButton: "डेटा अपलोड करें",
//       geolocationError: "भू-स्थान ब्लॉक कर दिया गया है।",
//       geolocationNotSupported: "आपका ब्राउज़र भू-स्थान का समर्थन नहीं करता।",
//       speechNotSupported: "आपका ब्राउज़र वाक् पहचान का समर्थन नहीं करता है।",
//       speechError: "वाक् पहचान में त्रुटि। कृपया पुनः प्रयास करें।",
//       speakHeader: "फॉर्म शीर्षक बोलें",
//       stateLabel: "राज्य",
//       countryLabel: "देश",
//       pincodeLabel: "पिनकोड",
//       fullAddressLabel: "पूरा पता",
//     },
//   };

//   // --- Geolocation ---
//   useEffect(() => {
//     if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition(
//         async (pos) => {
//           const { latitude, longitude } = pos.coords;
//           const address = await getAddressFromCoords(latitude, longitude);
//           setFormData((prev) => ({
//             ...prev,
//             geoLocation: { lat: latitude, long: longitude },
//             ...address,
//           }));
//         },
//         () => {
//           setStatus(translations[language].geolocationError);
//           setFormData((prev) => ({
//             ...prev,
//             geoLocation: { lat: "Blocked", long: "Blocked" },
//           }));
//         }
//       );
//     } else {
//       setStatus(translations[language].geolocationNotSupported);
//     }
//   }, [language]);

//   // --- QR helpers ---
//   const generateLocalHash = () =>
//     `local_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
//   const getHiddenQRDataUrl = () => {
//     try {
//       if (!hiddenQRContainerRef.current) return null;
//       const canvas = hiddenQRContainerRef.current.querySelector("canvas");
//       return canvas ? canvas.toDataURL("image/png") : null;
//     } catch {
//       return null;
//     }
//   };

//   // --- Speech Synthesis (Text-to-Speech) ---
//   const handleSpeak = (text, lang) => {
//     if ('speechSynthesis' in window) {
//       window.speechSynthesis.cancel(); // Stop any previous speech
//       const utterance = new SpeechSynthesisUtterance(text);
//       utterance.lang = lang === 'hi' ? 'hi-IN' : 'en-US';
//       window.speechSynthesis.speak(utterance);
//     } else {
//       setStatus("Text-to-speech is not supported by your browser.");
//     }
//   };

//   // --- Speech Recognition (Voice Input) ---
//   const handleListen = (field) => {
//     if (listeningField) {
//       recognitionRef.current?.stop();
//       return;
//     }

//     const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
//     if (!SpeechRecognition) {
//       setStatus(translations[language].speechNotSupported);
//       return;
//     }

//     const recognition = new SpeechRecognition();
//     recognition.lang = language === 'hi' ? 'hi-IN' : 'en-US';
//     recognition.interimResults = false;

//     recognition.onstart = () => setListeningField(field);
//     recognition.onend = () => {
//       setListeningField(null);
//       recognitionRef.current = null;
//     };
//     recognition.onerror = (e) => {
//       console.error("Speech recognition error:", e.error);
//       setStatus(translations[language].speechError);
//     };

//     recognition.onresult = (event) => {
//       const transcript = event.results[0][0].transcript;
//       if (field === 'herbName') {
//         setHerbName(transcript);
//       } else if (field === 'quantity') {
//         const numbers = transcript.match(/\d+/g);
//         if (numbers) {
//           setQuantity(numbers.join(""));
//         }
//       }
//     };

//     recognition.start();
//     recognitionRef.current = recognition;
//   };

//   // --- Form Submit ---
//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setIsSaving(true);
//     const payloadBase = {
//       herbName,
//       date: formData.date,
//       quantity: Number(quantity),
//       geoLocation: formData.geoLocation,
//       farmerId: formData.farmerId,
//       city: formData.city,
//       state: formData.state,
//       country: formData.country,
//       pincode: formData.pincode,
//       fullAddress: formData.fullAddress,
//     };

//     try {
//       if (navigator.onLine) {
//         const response = await fetch(`${API}/herbs`, {
//           method: "POST",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify(payloadBase),
//         });
//         const data = await response.json();
//         setSubmittedHerb(data.herb || data.block || data);
//       } else {
//         const localHash = generateLocalHash();
//         const qrStr = `${FRONTEND}/${localHash}`;
//         setQrValue(qrStr);
//         const dataUrl = await new Promise((resolve) =>
//           requestAnimationFrame(() => resolve(getHiddenQRDataUrl()))
//         );
//         const offlinePayload = { ...payloadBase, localHash, qrDataUrl: dataUrl || null };
//         await saveOfflineHerb(offlinePayload);
//         setSubmittedHerb({ hash: localHash, herbName, quantity, qrDataUrl: dataUrl });
//       }
//     } catch {
//       const localHash = generateLocalHash();
//       const qrStr = `${FRONTEND}/${localHash}`;
//       setQrValue(qrStr);
//       const dataUrl = await new Promise((resolve) =>
//         requestAnimationFrame(() => resolve(getHiddenQRDataUrl()))
//       );
//       const offlinePayload = { ...payloadBase, localHash, qrDataUrl: dataUrl || null };
//       await saveOfflineHerb(offlinePayload);
//       setSubmittedHerb({ hash: localHash, herbName, quantity, qrDataUrl: dataUrl });
//     } finally {
//       setIsSaving(false);
//     }
//   };

//   const handleAddNew = () => {
//     setSubmittedHerb(null);
//     setHerbName("");
//     setQuantity("");
//     setFormData((prev) => ({ ...prev, date: getTodaysDate() }));
//     setQrValue("");
//     setStatus("");
//   };

//   const ReadOnlyField = ({ label, value }) => (
//     <div>
//       <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
//       <input
//         type="text"
//         value={value || "Fetching..."}
//         readOnly
//         className="mt-1 block w-full px-4 py-2 bg-gray-200 border border-gray-300 rounded-md shadow-sm cursor-not-allowed"
//       />
//     </div>
//   );

//   // --- Render ---
//   return (
//     <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
//       <div className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-2xl border border-gray-200">
//         {/* Hidden QR for offline saving */}
//         <div
//           style={{ position: "absolute", left: -9999, top: -9999 }}
//           aria-hidden="true"
//           ref={hiddenQRContainerRef}
//         >
//           {qrValue && <QRCode value={qrValue} size={256} level="H" includeMargin />}
//         </div>

//         {submittedHerb ? (
//           <div className="text-center">
//             <h1 className="text-3xl font-extrabold text-green-600">
//               {translations[language].successTitle}
//             </h1>
//             <p className="text-gray-600 mt-2 mb-6">
//               {translations[language].successSubtitle}
//             </p>
//             <div className="flex justify-center my-8 p-4 border rounded-lg">
//               <QRCode
//                 value={`${FRONTEND}/${submittedHerb.hash}`}
//                 size={256}
//                 level="H"
//                 includeMargin
//               />
//             </div>
//             <div className="text-left bg-gray-50 p-4 rounded-lg border">
//               <p><strong>Herb ID:</strong> {submittedHerb.hash}</p>
//               <p><strong>Herb Name:</strong> {submittedHerb.herbName}</p>
//               <p><strong>Quantity:</strong> {submittedHerb.quantity} grams</p>
//             </div>
//             <button
//               onClick={handleAddNew}
//               className="w-full mt-8 px-8 py-3 bg-green-600 text-white text-lg font-bold rounded-full shadow-lg hover:bg-green-700 transition-colors"
//             >
//               {translations[language].addAnother}
//             </button>
//           </div>
//         ) : (
//           <>
//             <div className="flex justify-between items-center mb-4 gap-4">
//               <h1 className="text-3xl font-extrabold text-gray-800 flex-1">
//                 {translations[language].formTitle}
//               </h1>
//               <div className="flex items-center gap-4">
//                 <button
//                   type="button"
//                   onClick={() => handleSpeak(translations[language].formTitle, language)}
//                   className="p-2 rounded-full hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500"
//                   aria-label={translations[language].speakHeader}
//                 >
//                   <SpeakerIcon />
//                 </button>
//                 <select
//                   value={language}
//                   onChange={(e) => setLanguage(e.target.value)}
//                   className="px-2 py-1 rounded-md border border-gray-300 shadow-sm focus:ring-green-500 focus:border-green-500"
//                 >
//                   <option value="en">English</option>
//                   <option value="hi">हिन्दी</option>
//                 </select>
//               </div>
//             </div>
//             <p className="text-gray-600 text-center mb-6">
//               {translations[language].formSubtitle}
//             </p>
//             <form onSubmit={handleSubmit} className="space-y-6">
//               {/* Herb Name */}
//               <div>
//                 <label htmlFor="herbName" className="block text-sm font-medium text-gray-700 mb-1">
//                   {translations[language].herbNameLabel}
//                 </label>
//                 <div className="relative">
//                   <input
//                     type="text"
//                     id="herbName"
//                     value={herbName}
//                     onChange={(e) => setHerbName(e.target.value)}
//                     placeholder={translations[language].herbNameLabel}
//                     className="mt-1 block w-full pl-4 pr-12 py-2 bg-gray-100 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500 transition-colors"
//                     required
//                   />
//                   <button
//                     type="button"
//                     onClick={() => handleListen('herbName')}
//                     className="absolute inset-y-0 right-0 flex items-center pr-3 cursor-pointer"
//                     aria-label="Activate voice input for herb name"
//                   >
//                     <MicIcon isListening={listeningField === 'herbName'} />
//                   </button>
//                 </div>
//               </div>

//               {/* Quantity */}
//               <div>
//                 <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-1">
//                   {translations[language].quantityLabel}
//                 </label>
//                 <div className="relative">
//                   <input
//                     type="number"
//                     id="quantity"
//                     value={quantity}
//                     onChange={(e) => setQuantity(e.target.value)}
//                     placeholder={translations[language].quantityLabel}
//                     className="mt-1 block w-full pl-4 pr-12 py-2 bg-gray-100 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500 transition-colors"
//                     required
//                   />
//                   <button
//                     type="button"
//                     onClick={() => handleListen('quantity')}
//                     className="absolute inset-y-0 right-0 flex items-center pr-3 cursor-pointer"
//                     aria-label="Activate voice input for quantity"
//                   >
//                     <MicIcon isListening={listeningField === 'quantity'} />
//                   </button>
//                 </div>
//               </div>

//               <ReadOnlyField label={translations[language].dateLabel} value={formData.date} />
//               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//                 <ReadOnlyField label={translations[language].latitudeLabel} value={formData.geoLocation.lat} />
//                 <ReadOnlyField label={translations[language].longitudeLabel} value={formData.geoLocation.long} />
//                 <ReadOnlyField label={translations[language].farmerIdLabel} value={formData.farmerId} />
//                 <ReadOnlyField label={translations[language].stateLabel} value={formData.state} />
//                 <ReadOnlyField label={translations[language].countryLabel} value={formData.country} />
//                 <ReadOnlyField label={translations[language].pincodeLabel} value={formData.pincode} />
//                 <ReadOnlyField label={translations[language].fullAddressLabel} value={formData.fullAddress} />
//               </div>
//               <button
//                 type="submit"
//                 disabled={isSaving}
//                 className={`w-full px-8 py-3 ${isSaving ? "bg-green-400 cursor-not-allowed" : "bg-green-600 hover:bg-green-700"} text-white text-lg font-bold rounded-full shadow-lg transition-colors flex items-center justify-center space-x-3`}
//               >
//                 {isSaving ? (
//                   <>
//                     <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
//                       <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
//                       <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
//                     </svg>
//                     <span>Saving...</span>
//                   </>
//                 ) : (
//                   <>{translations[language].uploadButton}</>
//                 )}
//               </button>
//             </form>
//             {status && (
//               <p className="mt-4 text-center text-sm font-medium text-red-600">{status}</p>
//             )}
//           </>
//         )}
//       </div>
//     </div>
//   );
// };

// export default UploadHerbDataform;