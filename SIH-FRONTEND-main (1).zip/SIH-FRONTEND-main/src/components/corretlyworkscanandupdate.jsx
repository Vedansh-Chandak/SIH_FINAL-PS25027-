import React, { useEffect, useState } from "react";
import { Html5QrcodeScanner } from "html5-qrcode";
import QRCode from "qrcode";

const API = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";
const FRONTEND = import.meta.env.VITE_FRONTEND || "http://localhost:5173";

const ScanUpdateBatch = ({ user }) => { // <-- receive user prop
  const [herb, setHerb] = useState(null);
  const [qrImage, setQrImage] = useState("");
  const [qrLink, setQrLink] = useState("");
  const [link, setLink] = useState("");
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(false);

  // Fetch herb details
  const fetchHerb = async (herbId) => {
    try {
      const res = await fetch(`${API}/herbs/${herbId}`);
      if (!res.ok) throw new Error("Failed to fetch herb");
      const data = await res.json();
      if (!data.success) throw new Error("Herb not found");

      let farmerName = "";
      try {
        const farmerRes = await fetch(`${API}/users/${data.herb.farmer}`);
        if (farmerRes.ok) {
          const farmerData = await farmerRes.json();
          farmerName = farmerData?.user?.name || "";
        }
      } catch (err) {
        console.warn("⚠️ Failed to fetch farmer name:", err);
      }

      setHerb({ ...data.herb, farmerName });

      setFormData({
        herbName: data.herb.herbName,
        date: data.herb.date?.split("T")[0] || "",
        quantity: data.herb.quantity,
        geoLocation: data.herb.geoLocation || { lat: "", long: "" },
        city: data.herb.city,
        address: data.herb.address,
        county: data.herb.county,
        pincode: data.herb.pincode,
        farmerId: data.herb.farmer,
        farmerName,
        transportCity: "",
        transportPincode: "",
        transportGeoLocation: { lat: "", long: "" },
        driverName: "",
        vehicleNumber: "",
        transportQuantity: "",
      });
    } catch (err) {
      console.error("❌ Error fetching herb:", err);
      setHerb(null);
    }
  };

  const extractHerbId = (url) => {
    const parts = url.split("/");
    return parts.pop() || parts.pop();
  };

  const handleLinkSubmit = (e) => {
    e.preventDefault();
    const herbId = extractHerbId(link);
    if (herbId) fetchHerb(herbId);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "transportLat") {
      setFormData((prev) => ({
        ...prev,
        transportGeoLocation: { ...prev.transportGeoLocation, lat: value },
      }));
    } else if (name === "transportLong") {
      setFormData((prev) => ({
        ...prev,
        transportGeoLocation: { ...prev.transportGeoLocation, long: value },
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleTransportSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        transportGeoLocation: {
          lat: Number(formData.transportGeoLocation.lat),
          long: Number(formData.transportGeoLocation.long),
        },
        transportQuantity: Number(formData.transportQuantity),
      };

      const res = await fetch(`${API}/transport`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      console.log("✅ Transport response:", data);

      if (data.success && data.transport?._id) {
        const transportId = data.transport._id;
        const qrPayload = `${API}/transport/${transportId}`;
        const qrDataUrl = await QRCode.toDataURL(qrPayload);

        await fetch(`${API}/transport/${transportId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ qrPayload, qrImage: qrDataUrl }),
        });

        setQrImage(qrDataUrl);
        setQrLink(qrPayload);

        alert("Transport submitted and QR generated successfully!");

        setFormData((prev) => ({
          ...prev,
          transportCity: "",
          transportPincode: "",
          transportGeoLocation: { lat: "", long: "" },
          driverName: "",
          vehicleNumber: "",
          transportQuantity: "",
        }));
      } else {
        alert("❌ Transport submission failed.");
      }
    } catch (err) {
      console.error("❌ Error submitting transport:", err);
      alert("Failed to submit transport.");
    }

    setLoading(false);
  };

  useEffect(() => {
    const scanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
    const success = (decodedText) => {
      scanner.clear();
      const herbId = extractHerbId(decodedText);
      if (herbId) fetchHerb(herbId);
    };
    scanner.render(success, (err) => console.warn("⚠️ QR scan error:", err));
    return () => scanner.clear().catch(() => {});
  }, []);

  return (
    <div className="flex flex-col items-center p-6">
      <h1 className="text-2xl font-bold mb-4">Scan QR or Enter Link</h1>

      <div id="reader" className="w-full max-w-md border rounded-md shadow-md mb-6" />

      <form onSubmit={handleLinkSubmit} className="w-full max-w-md flex gap-2 mb-6">
        <input
          type="text"
          placeholder="Paste herb link here..."
          value={link}
          onChange={(e) => setLink(e.target.value)}
          className="flex-1 border px-3 py-2 rounded-md"
        />
        <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded-md">
          Open
        </button>
      </form>

      {herb && (
        <div className="mt-4 p-4 border rounded bg-white shadow-md w-full max-w-lg flex flex-col gap-2">
          <h2 className="font-bold text-lg mb-2">Herb Details</h2>

          <input
            name="herbName"
            value={formData.herbName || ""}
            readOnly
            className="border px-3 py-2 rounded"
          />
          <input
            name="date"
            type="date"
            value={formData.date || ""}
            readOnly
            className="border px-3 py-2 rounded"
          />
          <input
            name="quantity"
            type="number"
            value={formData.quantity || ""}
            readOnly
            className="border px-3 py-2 rounded"
          />

          {/* If user is not farmer, show full transport form + QR */}
          {user.role !== "farmer" && (
            <>
              <input
                name="farmerName"
                value={formData.farmerName || ""}
                readOnly
                className="border px-3 py-2 rounded"
              />
              <input
                name="transportCity"
                placeholder="Transport City"
                value={formData.transportCity || ""}
                onChange={handleChange}
                className="border px-3 py-2 rounded"
              />
              <input
                name="transportPincode"
                placeholder="Transport Pincode"
                value={formData.transportPincode || ""}
                onChange={handleChange}
                className="border px-3 py-2 rounded"
              />
              <input
                name="transportLat"
                placeholder="Transport Latitude"
                value={formData.transportGeoLocation?.lat || ""}
                onChange={handleChange}
                className="border px-3 py-2 rounded"
              />
              <input
                name="transportLong"
                placeholder="Transport Longitude"
                value={formData.transportGeoLocation?.long || ""}
                onChange={handleChange}
                className="border px-3 py-2 rounded"
              />
              <input
                name="driverName"
                placeholder="Driver Name"
                value={formData.driverName || ""}
                onChange={handleChange}
                className="border px-3 py-2 rounded"
              />
              <input
                name="vehicleNumber"
                placeholder="Vehicle Number"
                value={formData.vehicleNumber || ""}
                onChange={handleChange}
                className="border px-3 py-2 rounded"
              />
              <input
                name="transportQuantity"
                type="number"
                placeholder="Transport Quantity"
                value={formData.transportQuantity || ""}
                onChange={handleChange}
                className="border px-3 py-2 rounded"
              />

              <button
                type="submit"
                disabled={loading}
                onClick={handleTransportSubmit}
                className="bg-blue-600 text-white px-4 py-2 rounded mt-2"
              >
                {loading ? "Submitting..." : "Submit Transport"}
              </button>

              {qrImage && (
                <div className="mt-4 flex flex-col items-center">
                  <h3 className="font-semibold mb-2">Transport QR Code</h3>
                  <img src={qrImage} alt="QR Code" className="w-48 h-48" />
                  <a
                    href={qrLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 text-blue-600 underline"
                  >
                    Open Transport Link
                  </a>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default ScanUpdateBatch;
