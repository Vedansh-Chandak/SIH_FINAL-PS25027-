import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import QRCode from "qrcode";
import { useTranslation } from "react-i18next";

// --- API and Frontend URLs ---
const API = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";
const FRONTEND = import.meta.env.VITE_FRONTEND;

// --- Icon Components ---
const MicIcon = ({ isListening }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${isListening ? 'text-green-500 animate-pulse' : 'text-gray-400 hover:text-gray-600'}`} viewBox="0 0 20 20" fill="currentColor">
    <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8h-1a6 6 0 11-12 0H3a7.001 7.001 0 006 6.93V17H7a1 1 0 100 2h6a1 1 0 100-2h-2v-2.07z" clipRule="evenodd" />
  </svg>
);
const SpeakerIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400 hover:text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
    </svg>
);

// --- Reusable Input Components ---
const InputWithVoice = ({ name, type, placeholder, value, onChange, onSpeak, onListen, isListening, listeningField }) => (
  <div>
    <label htmlFor={name} className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-1">
      <span onClick={() => onSpeak(placeholder)} className="cursor-pointer transition-colors"><SpeakerIcon /></span>
      {placeholder}
    </label>
    <div className="relative">
      <input type={type} id={name} name={name} value={value} onChange={onChange} placeholder={placeholder} required className="w-full px-3 py-2 pr-10 text-gray-800 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all" />
      <div onClick={() => onListen(name)} className="absolute inset-y-0 right-0 flex items-center pr-3 cursor-pointer">
        <MicIcon isListening={isListening && listeningField === name} />
      </div>
    </div>
  </div>
);

const SimpleInput = ({ name, type, placeholder, value, onChange, readOnly = false }) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">{placeholder}</label>
    <input type={type} id={name} name={name} value={value} onChange={onChange} required className={`w-full px-3 py-2 text-gray-800 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all ${readOnly ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'}`} readOnly={readOnly} />
  </div>
);

// --- Main Form Component ---
const UploadHerbDataForm = ({ user }) => {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    herbName: "", date: new Date().toISOString().split('T')[0], quantity: "", city: "",
    address: "", county: "", pincode: "", country: "", latitude: "", longitude: "", farmerId: "",
  });

  const [farmerName, setFarmerName] = useState("Loading...");
  const [loading, setLoading] = useState(false);
  const [isFetchingLocation, setIsFetchingLocation] = useState(false);
  const [qrData, setQrData] = useState({ qrPayload: "", qrImage: "" });
  const [isListening, setIsListening] = useState(false);
  const [listeningField, setListeningField] = useState(null);
  
  useEffect(() => {
    if (user?._id) {
      setFormData((prev) => ({ ...prev, farmerId: user._id }));
      setFarmerName(user.name || "N/A");
    }
  }, [user]);

  useEffect(() => {
    handleGeolocation();
  }, []);

  const handleGeolocation = useCallback(() => {
    if (!navigator.geolocation) { alert("Geolocation is not supported by your browser."); return; }
    setIsFetchingLocation(true);
    const options = { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 };
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        try {
          const nominatimUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`;
          const response = await fetch(nominatimUrl);
          if (!response.ok) throw new Error("Failed to fetch address details.");
          const data = await response.json();
          const addr = data.address;
          setFormData((prev) => ({ ...prev, latitude: latitude.toFixed(6), longitude: longitude.toFixed(6), address: data.display_name || "", city: addr.city || addr.town || addr.city_district || addr.state_district || addr.village || "", county: addr.state || "", pincode: addr.postcode || "", country: addr.country || "" }));
        } catch (error) {
          console.error("Reverse geocoding error:", error);
          setFormData(prev => ({ ...prev, latitude: latitude.toFixed(6), longitude: longitude.toFixed(6) }));
          alert("Could not fetch address details, but coordinates were set. Please fill in the address manually.");
        } finally {
          setIsFetchingLocation(false);
        }
      },
      (error) => {
        console.error(`Geolocation Error: ${error.message}`);
        alert(`Error: ${error.message}. Please ensure location services are enabled.`);
        setIsFetchingLocation(false);
      },
      options
    );
  }, []);
  
  const handleChange = useCallback((e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  }, []);
  
  const speakLabel = useCallback((text) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = i18n.language === 'hi' ? 'hi-IN' : 'en-US';
      window.speechSynthesis.speak(utterance);
    }
  }, [i18n.language]);
  
  const handleListen = useCallback((fieldName) => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { alert("Sorry, your browser doesn't support voice recognition."); return; }
    const recognition = new SpeechRecognition();
    recognition.lang = i18n.language === 'hi' ? 'hi-IN' : 'en-US';
    recognition.onstart = () => { setIsListening(true); setListeningField(fieldName); };
    recognition.onresult = (event) => {
      let transcript = event.results[0][0].transcript;
      if (fieldName === 'quantity') {
        const numericValue = transcript.match(/\d+/);
        transcript = numericValue ? numericValue[0] : '';
      }
      setFormData(prev => ({...prev, [fieldName]: transcript}));
    };
    recognition.onend = () => { setIsListening(false); setListeningField(null); };
    recognition.start();
  }, [i18n.language]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setQrData({ qrPayload: "", qrImage: "" });
    try {
      if (!formData.latitude || !formData.longitude) { throw new Error("Location is required. Please allow access and try again."); }
      const initialPayload = { ...formData, quantity: Number(formData.quantity), geoLocation: { lat: parseFloat(formData.latitude), long: parseFloat(formData.longitude) } };
      const res = await fetch(`${API}/herbs`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(initialPayload) });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.message || "Herb upload failed");
      const herbId = data.herb._id;
      const qrPayload = `${FRONTEND}/herbs/${herbId}`;
      const qrImage = await QRCode.toDataURL(qrPayload, { width: 256 });
      await fetch(`${API}/herbs/${herbId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ qrPayload, qrImage }) });
      setQrData({ qrPayload, qrImage });
      setFormData({ herbName: "", date: new Date().toISOString().split('T')[0], quantity: "", city: "", address: "", county: "", pincode: "", country: "", latitude: "", longitude: "", farmerId: user?._id || "" });
      alert(t('successAlert'));
    } catch (err) {
      console.error(err);
      alert(`Error: ${err.message || "Failed to upload herb data."}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="bg-slate-50 min-h-screen py-8 px-4 ">
      {/* MODIFIED: Reduced max-width and padding */}
      <div className="max-w-3xl mx-auto bg-white p-6 md:p-8 rounded-2xl shadow-xl border border-gray-300">
        
        {/* MODIFIED: Reduced margin-bottom */}
        <div className="flex justify-between items-start mb-6">
            <div>
                <h1 className="text-2xl font-bold text-gray-800 tracking-tight">{t('title')}</h1>
                <p className="text-gray-500 mt-1 text-sm">{t('subtitle')}</p>
            </div>
            <select onChange={(e) => i18n.changeLanguage(e.target.value)} defaultValue={i18n.language} className="border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 transition text-sm">
                <option value="en">English</option>
                <option value="hi">हिंदी</option>
            </select>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
            {/* MODIFIED: Reduced grid gaps */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                <InputWithVoice name="herbName" type="text" placeholder={t("herbName")} value={formData.herbName} onChange={handleChange} onSpeak={speakLabel} onListen={handleListen} isListening={isListening} listeningField={listeningField} />
                <InputWithVoice name="quantity" type="number" placeholder={t("quantityKgs")} value={formData.quantity} onChange={handleChange} onSpeak={speakLabel} onListen={handleListen} isListening={isListening} listeningField={listeningField} />
                <SimpleInput name="date" type="date" placeholder={t("date")} value={formData.date} onChange={handleChange} />
                <div>
                    <label htmlFor="farmerName" className="block text-sm font-medium text-gray-700 mb-1">{t("farmerName")}</label>
                    <input type="text" id="farmerName" name="farmerName" value={farmerName} readOnly className="w-full px-3 py-2 border rounded-lg bg-gray-100 cursor-not-allowed" />
                </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-gray-200">
                <div className="flex justify-between items-center">
                    <h2 className="text-lg font-semibold text-gray-700">Location Details</h2>
                    <button type="button" onClick={handleGeolocation} disabled={isFetchingLocation} className="px-3 py-1.5 text-xs font-semibold text-green-700 bg-green-50 rounded-lg hover:bg-green-100 transition-colors disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed">
                        {isFetchingLocation ? t('fetchingLocation') : t('getLocation')}
                    </button>
                </div>
                {/* MODIFIED: Reduced padding and gaps */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 p-4 bg-slate-50 rounded-xl">
                    <SimpleInput name="latitude" type="text" placeholder={t("latitude")} value={formData.latitude} onChange={handleChange}  />
                    <SimpleInput name="longitude" type="text" placeholder={t("longitude")} value={formData.longitude} onChange={handleChange}  />
                    <div className="md:col-span-2">
                        <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">{t('address')}</label>
                        <textarea id="address" name="address" value={formData.address} onChange={handleChange} rows={2} required className="w-full px-3 py-2 text-gray-800 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all" />
                    </div>
                    <SimpleInput name="city" type="text" placeholder={t("city")} value={formData.city} onChange={handleChange} />
                    <SimpleInput name="county" type="text" placeholder={t("state")} value={formData.county} onChange={handleChange} />
                    <SimpleInput name="pincode" type="text" placeholder={t("pincode")} value={formData.pincode} onChange={handleChange} />
                    <SimpleInput name="country" type="text" placeholder={t("country")} value={formData.country} onChange={handleChange} />
                </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200 flex justify-end">
                <button type="submit" disabled={loading} className="w-full md:w-auto px-8 py-2.5 bg-green-600 text-white font-bold text-base rounded-lg shadow-md hover:bg-green-700 focus:outline-none focus:ring-4 focus:ring-green-300 transition-all duration-300 disabled:bg-gray-400 disabled:shadow-none">
                    {loading ? t("uploading") : t("submit")}
                </button>
            </div>
        </form>

        {qrData.qrImage && (
          <div className="mt-8 p-4 bg-green-50 border-l-4 border-green-400 rounded-r-lg flex flex-col items-center text-center">
            <h3 className="font-semibold text-lg text-green-800 mb-2">{t("success")}</h3>
            <img src={qrData.qrImage} alt="Herb QR Code" className="w-40 h-40 mb-3 rounded-lg shadow-md" />
            <a href={qrData.qrPayload} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 underline break-all text-sm transition-colors">
                {t("openLink")}
            </a>
          </div>
        )}
      </div>
    </main>
  );
};

export default UploadHerbDataForm;