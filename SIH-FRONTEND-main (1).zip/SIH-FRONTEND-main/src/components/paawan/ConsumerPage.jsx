import React from 'react';
import { Bar, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend,
  ArcElement 
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

// --- Helper Components & Icons (No Changes) ---

const UserIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>;
const LocationIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657l-4.243 4.243a2 2 0 01-2.828 0l-4.243-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const CheckBadgeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" /></svg>;
const CalendarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const LeafIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>;
const TruckIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>;
const FactoryIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m-1 4h1m3-4h1m-1 4h1m-1-4h1m-1 4h1"></path></svg>;

const StatCard = ({ title, value, icon, valueColor = 'text-gray-900' }) => (
    <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 flex flex-col justify-between">
        <div className="flex justify-between items-center">
            <span className="text-gray-500 font-medium">{title}</span>
            {icon}
        </div>
        <p className={`text-2xl font-bold mt-2 ${valueColor}`}>{value}</p>
    </div>
);

const InfoCard = ({ title, icon, children }) => (
  <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
    <div className="flex items-center gap-3 mb-4">
      <div className="text-[#133215]">{icon}</div>
      <h3 className="text-xl font-bold text-gray-800">{title}</h3>
    </div>
    <div className="space-y-2 text-gray-600">{children}</div>
  </div>
);

const Tag = ({ children }) => <span className="inline-block bg-green-100 text-green-800 text-xs font-semibold mr-2 px-2.5 py-1 rounded-full">{children}</span>;

// --- Main Consumer Page Component ---

const ConsumerPage = () => {
  // Sample Data
  const productData = {
    herbName: "Tulsi",
    date: "2025-09-25T00:00:00.000Z",
    city: "Bhopal",
    address: "Village Road 12",
    pincode: "466001",
    farmerName: "Vinay",
    transportCity: "Bhopal",
    driverName: "KUNDAN",
    vehicleNumber: "98766t56",
    processingUnitName: "Herbal Processing Plant - Indore",
    processes: ["Cleaning", "Powdering", "Drying", "Packaging"],
    labName: "college",
    qualityAssurance: "Passed",
    certificates: ["ISO 9001", "GMP Certified"],
    moistureContent: 22,
    purityLevel: 32,
    pesticideLevel: 1.7,
    activeCompoundLevel: 22,
  };

  // --- Chart Configurations ---

  const pieChartData = {
    labels: ['Active Compound', 'Other Plant Matter'],
    datasets: [{
      data: [productData.activeCompoundLevel, 100 - productData.activeCompoundLevel],
      // **MODIFIED**: Mild multicolour palette
      backgroundColor: ['rgba(167, 209, 167, 0.8)', 'rgba(255, 229, 180, 0.8)'],
      borderColor: ['#ffffff'],
      borderWidth: 2,
    }],
  };
  const pieChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'bottom' },
    },
  };

  const barChartData = {
    labels: ['Moisture (%)', 'Purity (%)', 'Pesticide (ppm)', 'Active Comp. (%)'],
    datasets: [{
      label: 'Quality Metrics',
      data: [
        productData.moistureContent,
        productData.purityLevel,
        productData.pesticideLevel,
        productData.activeCompoundLevel,
      ],
      // **MODIFIED**: Array of mild colours for a multicolour bar chart
      backgroundColor: [
          'rgba(167, 209, 167, 0.7)',
          'rgba(159, 197, 232, 0.7)',
          'rgba(255, 229, 180, 0.7)',
          'rgba(199, 186, 221, 0.7)',
      ],
      borderColor: [
          'rgba(167, 209, 167, 1)',
          'rgba(159, 197, 232, 1)',
          'rgba(255, 229, 180, 1)',
          'rgba(199, 186, 221, 1)',
      ],
      borderWidth: 1,
      borderRadius: 5,
    }],
  };
  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: { y: { beginAtZero: true } },
  };

  return (
    <div className="bg-gray-100 min-h-screen font-sans">
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          {/* --- Header --- */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-[#133215]">{productData.herbName}</h1>
            <p className="text-gray-500 mt-1">Traceability & Quality Report</p>
          </div>

          {/* --- Stat Cards Section --- */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard title="Farmer" value={productData.farmerName} icon={<UserIcon />} />
            <StatCard title="Origin" value={`${productData.city}, ${productData.pincode}`} icon={<LocationIcon />} />
            <StatCard title="Quality Status" value={productData.qualityAssurance} icon={<CheckBadgeIcon />} valueColor="text-green-600" />
            <StatCard title="Harvest Date" value={new Date(productData.date).toLocaleDateString()} icon={<CalendarIcon />} />
          </div>

          {/* --- Charts Section --- */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Pie Chart Card */}
            <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
                <h2 className="text-xl font-bold text-gray-800 mb-4 text-center">Product Composition</h2>
                <div className="h-72">
                    <Pie data={pieChartData} options={pieChartOptions} />
                </div>
            </div>
            {/* Bar Chart Card */}
            <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
                <h2 className="text-xl font-bold text-gray-800 mb-4 text-center">Lab Analysis Metrics</h2>
                <div className="h-72">
                    <Bar options={barChartOptions} data={barChartData} />
                </div>
            </div>
          </div>


          {/* --- Journey & Details Section --- */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Timeline */}
            <div className="lg:col-span-1">
                <h3 className="text-xl font-bold text-gray-800 mb-4 pl-4">Product Journey</h3>
                <ol className="relative border-l border-gray-200">
                    <li className="mb-10 ml-4"><div className="absolute w-3 h-3 bg-green-500 rounded-full mt-1.5 -left-1.5 border border-white"></div><h3 className="text-lg font-semibold text-gray-900">Collected</h3><p className="text-sm text-gray-500">From {productData.farmerName}'s farm</p></li>
                    <li className="mb-10 ml-4"><div className="absolute w-3 h-3 bg-green-500 rounded-full mt-1.5 -left-1.5 border border-white"></div><h3 className="text-lg font-semibold text-gray-900">Processed</h3><p className="text-sm text-gray-500">At {productData.processingUnitName}</p></li>
                    <li className="mb-10 ml-4"><div className="absolute w-3 h-3 bg-green-500 rounded-full mt-1.5 -left-1.5 border border-white"></div><h3 className="text-lg font-semibold text-gray-900">Lab Verified</h3><p className="text-sm text-gray-500">By {productData.labName}</p></li>
                    <li className="ml-4"><div className="absolute w-3 h-3 bg-green-500 rounded-full mt-1.5 -left-1.5 border border-white"></div><h3 className="text-lg font-semibold text-gray-900">Dispatched</h3><p className="text-sm text-gray-500">Ready for market</p></li>
                </ol>
            </div>

            {/* Right Column: Details */}
            <div className="lg:col-span-2 space-y-8">
              <InfoCard title="Origin & Farming Details" icon={<LeafIcon />}>
                <p><strong>Farmer:</strong> {productData.farmerName}</p>
                <p><strong>Address:</strong> {productData.address}, {productData.city}, {productData.pincode}</p>
                <div className="mt-2 h-40 bg-gray-200 rounded-md flex items-center justify-center text-gray-500">Map Placeholder</div>
              </InfoCard>

              <InfoCard title="Logistics" icon={<TruckIcon />}>
                <p><strong>Driver:</strong> {productData.driverName}</p>
                <p><strong>Vehicle Number:</strong> {productData.vehicleNumber}</p>
              </InfoCard>

              <InfoCard title="Processing" icon={<FactoryIcon />}>
                <p><strong>Unit Name:</strong> {productData.processingUnitName}</p>
                <div><strong>Processes:</strong> {productData.processes.map(p => <Tag key={p}>{p}</Tag>)}</div>
                 <div className="mt-2"><strong>Certificates:</strong> {productData.certificates.map(c => <Tag key={c}>{c}</Tag>)}</div>
              </InfoCard>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ConsumerPage;