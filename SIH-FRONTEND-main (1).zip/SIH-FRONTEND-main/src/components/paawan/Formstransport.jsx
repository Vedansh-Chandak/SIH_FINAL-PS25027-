import React, { useState } from 'react';

const Formstransport = () => {
  const [formData, setFormData] = useState({
    herbName: '',
    quantity: '',
    date: new Date().toISOString().split('T')[0],
    latitude: '',
    longitude: '',
    farmerId: '',
    gender: '',
    state: '',
    country: 'India',
    pincode: '',
    fullAddress: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleGeolocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData((prevData) => ({
            ...prevData,
            latitude: position.coords.latitude.toFixed(6),
            longitude: position.coords.longitude.toFixed(6),
          }));
        },
        () => {
          alert('Could not get your location. Please enter it manually.');
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Submitted:', formData);
    alert('Harvest logged successfully!');
  };

  // Reusable component for input fields with a microphone icon
  const InputWithMic = ({ name, id, type = "text", value, onChange, required, children }) => (
    <div className="relative">
      <input
        type={type}
        name={name}
        id={id}
        value={value}
        onChange={onChange}
        required={required}
        className="w-full px-4 py-2 pr-10 border border-gray-300 rounded-md focus:ring-[#92B775] focus:border-[#92B775]"
      />
      <div className="absolute inset-y-0 right-0 flex items-center pr-3 cursor-pointer">
        {children}
      </div>
    </div>
  );
  
  const MicIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8h-1a6 6 0 11-12 0H3a7.001 7.001 0 006 6.93V17H7a1 1 0 100 2h6a1 1 0 100-2h-2v-2.07z" clipRule="evenodd" />
    </svg>
  );

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 text-gray-800 font-sans">
      {/* --- Navbar --- */}
      <nav className="bg-[#133215] text-white px-4 sm:px-8 py-3 flex justify-between items-center shadow-lg sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-12.5c.28 0 .5.22.5.5v1c0 .28-.22.5-.5.5h-1c-1.1 0-2 .9-2 2v1.5h1.5c.83 0 1.5.67 1.5 1.5v1c0 .83-.67 1.5-1.5 1.5H8v-1.5c0-1.93 1.57-3.5 3.5-3.5H12v-1.5c0-.83-.67-1.5-1.5-1.5h-1c-.28 0-.5-.22-.5-.5v-1c0-.28.22-.5.5-.5h1z" transform="scale(1.2) translate(-2, -2)"/><path d="M12,2A10,10,0,1,0,22,12,10,10,0,0,0,12,2Zm3.21,11.79A1,1,0,0,1,14,14H12.6A3.6,3.6,0,0,0,9,17.6V18a1,1,0,0,1-2,0V17.6A5.6,5.6,0,0,1,12.6,12H14a1,1,0,0,1,0,2Z"/><path d="M17.5,8.5A3.5,3.5,0,1,0,14,12h1.4A1.6,1.6,0,0,1,17,10.4V10a1,1,0,0,1,2,0v.4A3.6,3.6,0,0,0,17.5,8.5Z" fill="#92B775"/></svg>
          <h1 className="text-2xl font-bold tracking-wider">Sanjeevani</h1>
        </div>
      </nav>

      {/* --- Main Form Content --- */}
      <main className="flex-grow container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-2xl">
          <h2 className="text-3xl font-bold text-[#133215] mb-2 text-center">Log Your Herb Harvest</h2>
          <p className="text-center text-gray-600 mb-6">Fill in the details below to add your produce to the blockchain.</p>

          {/* --- Incentive Notice (Green Banner Style) --- */}
          <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-md mb-8 flex items-center gap-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
            </svg>
            <p className="text-sm font-medium">Female farmers are eligible for special bonus incentives for their harvest.</p>
          </div>
          
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="herbName" className="block text-sm font-medium text-gray-700 mb-1">Herb Name</label>
              <InputWithMic name="herbName" id="herbName" value={formData.herbName} onChange={handleChange} required><MicIcon /></InputWithMic>
            </div>

            <div>
              <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-1">Quantity (in grams)</label>
              <InputWithMic name="quantity" id="quantity" type="number" value={formData.quantity} onChange={handleChange} required><MicIcon /></InputWithMic>
            </div>

            <div>
              <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">Harvest Date</label>
              <InputWithMic name="date" id="date" type="date" value={formData.date} onChange={handleChange} required><MicIcon /></InputWithMic>
            </div>

            <div>
              <label htmlFor="farmerId" className="block text-sm font-medium text-gray-700 mb-1">Farmer ID</label>
              <InputWithMic name="farmerId" id="farmerId" value={formData.farmerId} onChange={handleChange} required><MicIcon /></InputWithMic>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Gender</label>
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="gender" value="Female" checked={formData.gender === 'Female'} onChange={handleChange} required className="focus:ring-[#92B775] h-4 w-4 text-[#133215] border-gray-300"/> <span className="text-gray-700">Female</span></label>
                <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="gender" value="Male" checked={formData.gender === 'Male'} onChange={handleChange} required className="focus:ring-[#92B775] h-4 w-4 text-[#133215] border-gray-300"/> <span className="text-gray-700">Male</span></label>
                <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="gender" value="Other" checked={formData.gender === 'Other'} onChange={handleChange} required className="focus:ring-[#92B775] h-4 w-4 text-[#133215] border-gray-300"/> <span className="text-gray-700">Other</span></label>
              </div>
            </div>
            
            <div className="md:col-span-2 border-t pt-6">
              <div className="flex justify-between items-center mb-1">
                <h3 className="text-lg font-semibold text-gray-800">Location Details</h3>
                <button type="button" onClick={handleGeolocation} className="px-3 py-1 text-xs font-semibold text-[#133215] bg-green-100 rounded-md hover:bg-green-200 transition">Get Current Location</button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div>
                  <label htmlFor="latitude" className="block text-sm font-medium text-gray-700 mb-1">Latitude</label>
                  <InputWithMic name="latitude" id="latitude" value={formData.latitude} onChange={handleChange} required><MicIcon /></InputWithMic>
                </div>
                <div>
                  <label htmlFor="longitude" className="block text-sm font-medium text-gray-700 mb-1">Longitude</label>
                  <InputWithMic name="longitude" id="longitude" value={formData.longitude} onChange={handleChange} required><MicIcon /></InputWithMic>
                </div>
              </div>
            </div>

            <div className="md:col-span-2">
              <label htmlFor="fullAddress" className="block text-sm font-medium text-gray-700 mb-1">Full Address</label>
              <div className="relative">
                <textarea name="fullAddress" id="fullAddress" rows="3" value={formData.fullAddress} onChange={handleChange} required className="w-full px-4 py-2 pr-10 border border-gray-300 rounded-md focus:ring-[#92B775] focus:border-[#92B775]"></textarea>
                <div className="absolute top-3 right-0 flex items-center pr-3 cursor-pointer"><MicIcon /></div>
              </div>
            </div>
            
            <div>
              <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">State</label>
              <InputWithMic name="state" id="state" value={formData.state} onChange={handleChange} required><MicIcon /></InputWithMic>
            </div>

            <div>
              <label htmlFor="pincode" className="block text-sm font-medium text-gray-700 mb-1">Pincode</label>
              <InputWithMic name="pincode" id="pincode" value={formData.pincode} onChange={handleChange} required><MicIcon /></InputWithMic>
            </div>

             <div>
              <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-1">Country</label>
              <input type="text" name="country" id="country" value={formData.country} onChange={handleChange} readOnly className="w-full px-4 py-2 border border-gray-300 rounded-md bg-gray-100" />
            </div>

            <div className="md:col-span-2 text-center mt-6">
              <button type="submit" className="w-full md:w-auto px-12 py-3 bg-[#92B775] text-white font-bold text-lg rounded-lg hover:bg-[#82a365] transition-all duration-300 shadow-lg">Submit</button>
            </div>
          </form>
        </div>
      </main>

      {/* --- Footer --- */}
      <footer className="bg-[#133215] text-white py-8 px-6">
        <div className="max-w-6xl mx-auto text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} Ministry of AYUSH, Government of India. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Formstransport;