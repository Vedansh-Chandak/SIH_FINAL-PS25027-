// HomePage.jsx
import React, { useState, useEffect } from "react";

// FIXED: Corrected the import paths to go up one directory
import image1 from '../assets/1.jpg';
import image2 from '../assets/2.jpg';
import image3 from '../assets/3.jpg';
import image4 from '../assets/qrscan.jpg'; 
import image5 from '../assets/about.jpg'; 
import image6 from '../assets/Logo.png';
import image7 from '../assets/quality.jpg'

// MODIFIED: Replaced the last three Pexels URLs with your imported images
const sliderImages = [
  "https://images.pexels.com/photos/235925/pexels-photo-235925.jpeg?auto=compress&cs=tinysrgb&w=1600", // Farmer in a field (Unchanged)
  image1, // Your 1.jpg
  image2, // Your 2.jpg
  image3, // Your 3.jpg
];

// Data for the benefits section with SVG icons
const benefits = [
  { 
    icon: (
      <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
      </svg>
    ), 
    title: 'For Farmers', 
    description: 'Earn more for high-quality, certified Ayurvedic herbs through a transparent system.' 
  },
  { 
    icon: (
      <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 14v1.5a2 2 0 01-2 2H8a2 2 0 01-2-2V14m0-4h.01M5 8h.01M21 12h.01M16 6v1a4 4 0 01-4 4h-1.5a4 4 0 01-4-4V6m6 0h.01M10 21v-2a4 4 0 014-4h.5"/>
      </svg>
    ), 
    title: 'For Women Farmers', 
    description: 'Access special incentives, training, and recognition for your contribution.' 
  },
  { 
    icon: (
      <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
      </svg>
    ), 
    title: 'For Consumers', 
    description: 'Trust in safe, authentic Ayurvedic products with verifiable origins.' 
  },
  { 
    icon: (
      <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2h7a2 2 0 002-2v-1a2 2 0 012-2h2.945M10 7l2-2m0 0l2 2M12 5v14"/>
      </svg>
    ), 
    title: 'For Society', 
    description: 'Support sustainable farming and help preserve India’s rich Ayurvedic heritage.' 
  },
  { 
    icon: (
      <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
      </svg>
    ), 
    title: 'For Government', 
    description: 'Ensure regulatory compliance and transparency across the supply chain.' 
  }
];

// Reusable Feature Card component
const FeatureCard = ({ icon, title, desc }) => (
  <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl hover:-translate-y-2 transition-all duration-300 ease-in-out w-full sm:w-64 text-center">
    <div className="flex justify-center items-center mb-4 h-16 w-16 mx-auto bg-green-100 rounded-full">{icon}</div>
    <h3 className="text-xl font-bold text-[#133215] mb-2">{title}</h3>
    <p className="text-gray-600 text-sm leading-relaxed">{desc}</p>
  </div>
);


const HomePage = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const prevSlide = () => setCurrentSlide((prev) => (prev === 0 ? sliderImages.length - 1 : prev - 1));
  const nextSlide = () => setCurrentSlide((prev) => (prev === sliderImages.length - 1 ? 0 : prev + 1));

  useEffect(() => {
    const slideInterval = setInterval(nextSlide, 5000);
    return () => clearInterval(slideInterval);
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 text-gray-800 font-sans">
      {/* --- Navbar --- */}
      <nav className="bg-[#133215] text-white px-4 sm:px-8 py-3 flex justify-between items-center shadow-lg sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="flex-shrink-0">
            <img src={image6} alt="Sanjeevani Logo" className="h-12 w-auto" />
          </div>
        </div>
        <ul className="hidden lg:flex gap-8 text-md font-medium items-center">
          <li className="hover:text-[#92B775] cursor-pointer transition-colors duration-300">Home</li>
          <li className="hover:text-[#92B775] cursor-pointer transition-colors duration-300">About</li>
          <li className="hover:text-[#92B775] cursor-pointer transition-colors duration-300">How It Works</li>
          <li className="hover:text-[#92B775] cursor-pointer transition-colors duration-300">Benefits</li>
          <li className="hover:text-[#92B775] cursor-pointer transition-colors duration-300">Articles</li>
          <li className="hover:text-[#92B775] cursor-pointer transition-colors duration-300">Contact</li>
        </ul>
        <div className="hidden md:flex items-center gap-2">
           <button className="px-4 py-2 text-sm bg-transparent border border-white rounded-md hover:bg-white hover:text-[#133215] transition-colors duration-300">भाषा / EN</button>
           <button className="px-4 py-2 text-sm bg-[#92B775] text-[#133215] font-bold rounded-md hover:bg-[#a7c989] transition-colors duration-300">Login / Signup</button>
        </div>
        <button className="md:hidden text-2xl">☰</button>
      </nav>

      {/* --- Hero Slider --- */}
      <section className="relative w-full h-80 md:h-[32rem] overflow-hidden">
        <div className="w-full h-full flex transition-transform ease-in-out duration-1000" style={{ transform: `translateX(-${currentSlide * 100}%)` }}>
          {sliderImages.map((src, index) => <img key={index} src={src} alt={`Slide ${index}`} className="w-full h-full object-cover flex-shrink-0" />)}
        </div>
        
        <div className="absolute inset-0 bg-black/50 flex flex-col justify-center items-center text-center text-white p-4">
            {currentSlide === 0 && (
                <div className="animate-fade-in">
                    <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">Empowering Farmers, Ensuring Purity</h2>
                    <p className="mt-4 text-lg md:text-xl max-w-2xl mx-auto">Join the digital revolution in agriculture with blockchain-powered traceability for Ayurvedic herbs.</p>
                    <button className="mt-8 px-8 py-3 bg-[#92B775] text-[#133215] font-bold text-lg rounded-lg hover:bg-white transition-all duration-300 shadow-lg">Register as a Farmer</button>
                </div>
            )}
            {currentSlide === 1 && (
                <div className="animate-fade-in">
                    <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">Rewarding Excellence. Certified Quality.</h2>
                    <p className="mt-4 text-lg md:text-xl max-w-2xl mx-auto">We reward our partner farmers with premium bonuses and a Certificate of Excellence for cultivating herbs of the highest purity and potency.</p>
                </div>
            )}
            {currentSlide === 2 && (
                <div className="animate-fade-in">
                    <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">CHAMPIONING OUR WOMEN FARMERS.</h2>
                    <p className="mt-4 text-lg md:text-xl max-w-2xl mx-auto">We provide extra bonuses to women farmers, honoring their contribution and empowering rural communities.</p>
                </div>
            )}
            {currentSlide === 3 && (
                <div className="animate-fade-in">
                    <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">AI-POWERED PURITY. VERIFIED INSTANTLY.</h2>
                    <p className="mt-4 text-lg md:text-xl max-w-2xl mx-auto">Our AI verifies herb species, quality, and origin at the source. Transparency you can trust.</p>
                </div>
            )}
        </div>
        <button onClick={prevSlide} className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 p-2 rounded-full hover:bg-black/60 transition-colors">❮</button>
        <button onClick={nextSlide} className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 p-2 rounded-full hover:bg-black/60 transition-colors">❯</button>
      </section>
      
      {/* --- How It Works --- */}
      <section className="py-20 px-6 bg-gray-50">
        <div className="container mx-auto text-center">
            <h2 className="text-3xl font-bold text-[#133215] mb-12">Simple Steps to a Transparent Future</h2>
            <div className="grid md:grid-cols-3 gap-10 max-w-5xl mx-auto">
                <div className="flex flex-col items-center"><div className="bg-[#92B775] text-[#133215] text-2xl font-bold h-16 w-16 rounded-full flex items-center justify-center">1</div><h3 className="text-xl font-semibold text-[#133215] mt-4">Register & List</h3><p className="text-gray-600 mt-2">Farmers register their land and crops on our secure platform.</p></div>
                <div className="flex flex-col items-center"><div className="bg-[#92B775] text-[#133215] text-2xl font-bold h-16 w-16 rounded-full flex items-center justify-center">2</div><h3 className="text-xl font-semibold text-[#133215] mt-4">Trace with QR</h3><p className="text-gray-600 mt-2">Each batch gets a unique QR code, logged on the blockchain.</p></div>
                <div className="flex flex-col items-center"><div className="bg-[#92B775] text-[#133215] text-2xl font-bold h-16 w-16 rounded-full flex items-center justify-center">3</div><h3 className="text-xl font-semibold text-[#133215] mt-4">Verify & Trust</h3><p className="text-gray-600 mt-2">Consumers scan the code to see the product's entire journey.</p></div>
            </div>
        </div>
      </section>

      {/* --- Scan QR Section --- */}
      <section className="py-20 px-6 bg-white">
        <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div className="flex justify-center">
            <img src={image4} alt="Scanning a QR code on a product" className="rounded-lg shadow-xl max-w-sm w-full" />
          </div>
          <div className="text-center md:text-left px-4">
            <h3 className="text-lg font-semibold text-[#92B775]">TRANSPARENCY IN YOUR HANDS</h3>
            <h2 className="text-3xl font-bold text-[#133215] mt-2 mb-4">Verify Authenticity Instantly</h2>
            <p className="text-gray-700 text-lg leading-relaxed mb-8">Curious about where your Ayurvedic products come from? Simply scan the QR code on the packaging with your smartphone to trace the complete journey of your herb, from the farm to your hands. Empower yourself with knowledge and trust in every purchase.</p>
            <button className="px-8 py-3 bg-[#92B775] text-[#133215] font-bold text-lg rounded-lg hover:bg-[#133215] hover:text-white transition-all duration-300 shadow-lg">Scan a QR Code</button>
          </div>
        </div>
      </section>

      {/* --- Key Features Section --- */}
      <section className="py-20 px-6 bg-[#F3E8D3]">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-[#133215] mb-4">A Platform Built on Trust and Technology</h2>
          <p className="text-gray-600 mb-12 max-w-3xl mx-auto">Sanjeevani bridges the gap between dedicated farmers and conscious consumers, ensuring transparency at every step.</p>
          <div className="flex flex-wrap justify-center gap-8">
             <FeatureCard icon={<svg className="w-8 h-8 text-[#133215]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>} title="Easy Farmer Registration" desc="A simple, voice-assisted process for quick and easy onboarding." />
             <FeatureCard icon={<svg className="w-8 h-8 text-[#133215]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>} title="Consumer Trust" desc="Verify product authenticity and origin instantly with a QR scan." />
             <FeatureCard icon={<svg className="w-8 h-8 text-[#133215]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>} title="Fair Pricing" desc="Get rewarded fairly for high-quality, organic produce through a transparent system." />
             <FeatureCard icon={<svg className="w-8 h-8 text-[#133215]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>} title="Women Empowerment" desc="Special focus and benefits for women farmers and Self-Help Groups (SHGs)." />
          </div>
        </div>
      </section>

      {/* --- NEW: AI Quality Analysis Section --- */}
      <section className="py-20 px-6 bg-white">
        <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
            <div className="px-4 md:order-1 order-2">
                <h3 className="text-lg font-semibold text-[#92B775]">INSTANT. ACCURATE. AI-POWERED.</h3>
                <h2 className="text-3xl font-bold text-[#133215] mt-2 mb-4">Instant Herb Quality Analysis</h2>
                <p className="text-gray-700 text-lg leading-relaxed mb-8">
                    Upload an image of your herb and let our advanced AI model provide an instant quality analysis. Our trained system evaluates key visual indicators to generate a precise quality percentage, ensuring your produce meets the highest standards before it ever reaches the market.
                </p>
                <a 
                    href="/quality-check" 
                    className="inline-block px-8 py-3 bg-[#92B775] text-[#133215] font-bold text-lg rounded-lg hover:bg-[#133215] hover:text-white transition-all duration-300 shadow-lg"
                >
                    Try the Quality Analyzer
                </a>
            </div>
            <div className="flex justify-center p-4 md:order-2 order-1">
                <img 
                    src={image7} 
                    alt="AI analyzing agricultural data" 
                    className="rounded-lg shadow-xl w-full max-w-lg" 
                />
            </div>
        </div>
      </section>

      {/* --- About Sanjeevani Section --- */}
      <section className="py-20 px-6 bg-gray-50"> {/* Changed background for visual separation */}
        <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div className="px-4">
            <h3 className="text-lg font-semibold text-[#92B775]">PRESERVING HERITAGE, EMPOWERING FARMERS</h3>
            <h2 className="text-3xl font-bold text-[#133215] mt-2 mb-4">About Sanjeevani</h2>
            <p className="text-gray-700 text-lg leading-relaxed">Sanjeevani is a government initiative that ensures traceability and trust in Ayurvedic herbs through blockchain technology. It rewards farmers for quality produce, supports women farmers, and allows consumers to verify authenticity with QR codes, while promoting sustainable farming and preserving India’s Ayurvedic heritage.</p>
          </div>
          <div className="flex justify-center p-4">
            <img 
              src={image5} 
              alt="Ayurvedic herbs and spices" 
              className="rounded-lg shadow-xl w-full max-w-sm" 
            />
          </div>
        </div>
      </section>

      {/* --- How Sanjeevani Benefits You Section --- */}
      <section className="py-20 px-6 bg-white">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-[#133215] mb-12">How Sanjeevani Benefits You</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto items-stretch justify-center">
            {benefits.slice(0, 3).map((benefit) => (
              <div key={benefit.title} className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                <div className="flex justify-center items-center mb-4 h-16 w-16 mx-auto bg-[#92B775] rounded-full">{benefit.icon}</div>
                <h3 className="text-xl font-bold text-[#133215] mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto mt-8">
            {benefits.slice(3).map((benefit) => (
              <div key={benefit.title} className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                 <div className="flex justify-center items-center mb-4 h-16 w-16 mx-auto bg-[#92B775] rounded-full">{benefit.icon}</div>
                <h3 className="text-xl font-bold text-[#133215] mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- YouTube Video Section --- */}
      <section className="py-20 px-6 bg-gray-50"> {/* Changed background for visual separation */}
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-[#133215] mb-4">Watch Our Platform in Action</h2>
          <p className="text-gray-600 mb-12 max-w-3xl mx-auto">See how Sanjeevani is revolutionizing the Ayurvedic supply chain. This short video demonstrates the journey of an herb from a registered farmer to a verified product, showcasing the simplicity and power of our blockchain platform.</p>
          <div className="max-w-4xl mx-auto aspect-video rounded-lg shadow-2xl overflow-hidden">
            <iframe 
                className="w-full h-full" 
                src="https://www.youtube.com/embed/dQw4w9WgXcQ" // Sample YouTube link
                title="Sanjeevani Platform Prototype" 
                frameBorder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen>
            </iframe>
          </div>
        </div>
      </section>

      {/* --- Articles and Announcements Section --- */}
      <section className="py-20 px-6 bg-[#F3E8D3]">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl font-bold text-[#133215] mb-12">Resources & Announcements</h2>
          <div className="bg-white rounded-lg shadow-lg p-8 text-left">
            {/* Related Articles */}
            <h3 className="text-xl font-bold text-[#133215] mb-4">Related Articles</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <svg className="w-5 h-5 text-[#92B775] mt-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                <a href="https://navbharattimes.indiatimes.com/lifestyle/health/6-herbs-that-flavor-food-and-improve-health-here-are-amazing-benefits/articleshow/86062934.cms" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">6 जड़ी-बूटियां, जो खाने का स्वाद बढ़ाने के साथ सेहत भी सुधारती हैं (Navbharat Times)</a>
              </li>
              <li className="flex items-start gap-3">
                <svg className="w-5 h-5 text-[#92B775] mt-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                <a href="https://hindi.news18.com/photogallery/lifestyle/health-medicinal-plant-health-benefit-these-5-medicinal-herbs-cures-multiple-diseases-useful-for-centuries-to-stay-healthy-and-fit-7853134.html" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">सदियों से सेहतमंद रहने के लिए अपनाए जा रहे हैं ये 5 औषधीय पौधे (News18 Hindi)</a>
              </li>
               <li className="flex items-start gap-3">
                <svg className="w-5 h-5 text-[#92B775] mt-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                <a href="https://www.onlymyhealth.com/topic/herbs-in-hindi" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">जड़ी-बूटियों से जुड़े लेख (OnlyMyHealth)</a>
              </li>
            </ul>

            <hr className="my-8 border-gray-200" />
            
            {/* Latest Announcements */}
            <h3 className="text-xl font-bold text-[#133215] mb-4">Latest Announcements</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4 pb-4 border-b"><div className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-md mt-1">NEW</div><p className="text-gray-700"><span className="font-semibold">18 Sept 2025:</span> New subsidy scheme announced for herbal farmers in the Gwalior-Chambal region. <a href="#" className="text-blue-600 hover:underline">Read more...</a></p></div>
              <div className="flex items-start gap-4 pb-4 border-b"><div className="bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded-md mt-1">EVENT</div><p className="text-gray-700"><span className="font-semibold">10 Sept 2025:</span> Training workshops scheduled in Uttar Pradesh for the upcoming season. <a href="#" className="text-blue-600 hover:underline">Register here</a></p></div>
              <div className="flex items-start gap-4"><div className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-md mt-1">INFO</div><p className="text-gray-700"><span className="font-semibold">05 Sept 2025:</span> Blockchain traceability pilot program successfully launched in Madhya Pradesh.</p></div>
            </div>
          </div>
        </div>
      </section>


      {/* --- Footer --- */}
      <footer className="bg-[#133215] text-white pt-16 pb-8 px-6 mt-auto">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2"><h3 className="font-bold text-xl mb-4">Sanjeevani</h3><p className="text-gray-300 text-sm">A Government of India initiative by the Ministry of AYUSH to promote, preserve, and protect our agricultural heritage through modern technology.</p></div>
          <div><h3 className="font-semibold mb-4">Quick Links</h3><ul className="space-y-2 text-sm text-gray-300"><li><a href="#" className="hover:text-white">About Us</a></li><li><a href="#" className="hover:text-white">Articles</a></li><li><a href="#" className="hover:text-white">RTI</a></li><li><a href="#" className="hover:text-white">Contact</a></li></ul></div>
          <div><h3 className="font-semibold mb-4">Contact</h3><ul className="space-y-2 text-sm text-gray-300"><li>Email: info@sanjeevani.gov.in</li><li>Phone: +91-11-12345678</li><li><a href="#" className="hover:text-white">Terms & Conditions</a></li><li><a href="#" className="hover:text-white">Privacy Policy</a></li></ul></div>
        </div>
        <div className="max-w-6xl mx-auto mt-8 pt-6 border-t border-gray-700 text-center text-sm text-gray-400"><p>&copy; {new Date().getFullYear()} Ministry of AYUSH, Government of India. All Rights Reserved.</p></div>
      </footer>
    </div>
  );
};

export default HomePage;