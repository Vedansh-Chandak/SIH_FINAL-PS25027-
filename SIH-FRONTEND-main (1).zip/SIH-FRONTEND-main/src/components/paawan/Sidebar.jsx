import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Leaf,
  Package,
  LogOut,
  User,
  FlaskConical,
  Microscope,
  Factory,
  Truck, // Added Truck icon for logistics
} from "lucide-react";

// Helper function for NavLink classes to keep the code DRY
const getNavLinkClass = ({ isActive }) =>
  `relative flex items-center gap-4 p-3 rounded-lg transition-colors duration-200 ${
    isActive
      ? "bg-[#1a431d] text-white" // Active link background using your UI's darker green shade
      : "text-gray-300 hover:bg-[#1a431d]/75 hover:text-white" // Hover state
  }`;

const Sidebar = ({ user, onSignOut }) => {
  return (
    // Set a fixed width and updated the background to your primary dark green UI color
    <aside className="w-64 h-screen bg-[#133215] text-white flex flex-col fixed top-0 left-0">
      
      {/* Logo / Header */}
      <div className="flex items-center gap-3 p-4 border-b border-white/10 h-20">
        <Leaf size={32} className="text-[#92B775]" /> {/* Using your UI's accent green */}
        <h1 className="text-2xl font-bold tracking-wider">HerbChain</h1>
      </div>

      {/* User Info Section */}
      {user && (
        <div className="p-4 border-b border-white/10 flex items-center gap-4">
          <User size={36} className="p-1.5 bg-black/20 rounded-full flex-shrink-0" />
          <div className="overflow-hidden">
            <p className="font-semibold text-sm truncate" title={user.name}>
              {user.name}
            </p>
            <p className="text-xs text-gray-400 capitalize">{user.role}</p>
          </div>
        </div>
      )}

      {/* Main container to push logout to the bottom */}
      <div className="flex flex-col justify-between flex-1">
        
        {/* Navigation Menu */}
        <nav className="flex-1 p-4 space-y-2">
          <NavLink to="/" className={getNavLinkClass}>
            {({ isActive }) => (
              <>
                {isActive && <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />}
                <LayoutDashboard size={22} />
                <span>Dashboard</span>
              </>
            )}
          </NavLink>

          <NavLink to="/upload-herb-data" className={getNavLinkClass}>
            {({ isActive }) => (
              <>
                {isActive && <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />}
                <Leaf size={22} />
                <span>Upload Herb Data</span>
              </>
            )}
          </NavLink>

          <NavLink to="/my-batches" className={getNavLinkClass}>
            {({ isActive }) => (
              <>
                {isActive && <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />}
                <Package size={22} />
                <span>My Batches</span>
              </>
            )}
          </NavLink>
          
          <p className="pt-4 pb-1 px-3 text-xs text-gray-400 font-semibold uppercase">Scan & Update</p>

          {/* NEW: Transport Logistics Link */}
          <NavLink to="/transportscan-update-batch" className={getNavLinkClass}>
             {({ isActive }) => (
              <>
                {isActive && <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />}
                <Truck size={22} />
                <span>Transport Logistics</span>
              </>
            )}
          </NavLink>

          <NavLink to="/processscan-update-batch" className={getNavLinkClass}>
             {({ isActive }) => (
              <>
                {isActive && <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />}
                <FlaskConical size={22} />
                <span>Processing Unit</span>
              </>
            )}
          </NavLink>

          <NavLink to="/labscan-update-batch" className={getNavLinkClass}>
             {({ isActive }) => (
              <>
                {isActive && <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />}
                <Microscope size={22} />
                <span>Lab</span>
              </>
            )}
          </NavLink>
          
          <NavLink to="/manufacturerscan-update-batch" className={getNavLinkClass}>
             {({ isActive }) => (
              <>
                {isActive && <div className="absolute left-0 h-6 w-1 bg-[#92B775] rounded-r-full" />}
                <Factory size={22} />
                <span>Manufacturer</span>
              </>
            )}
          </NavLink>
        </nav>

        {/* Logout Button */}
        <div className="p-4 border-t border-white/10">
          <button
            onClick={onSignOut}
            className="flex items-center w-full gap-4 p-3 rounded-lg transition-colors duration-200 text-gray-300 hover:bg-[#1a431d] hover:text-white"
          >
            <LogOut size={22} />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;