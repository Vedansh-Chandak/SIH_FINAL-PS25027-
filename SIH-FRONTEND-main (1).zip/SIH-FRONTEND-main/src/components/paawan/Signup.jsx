import React, { useState } from 'react';
import SignupImage from '../assets/farmerimage.jpg';

// Icon components remain the same
const GoogleIcon = () => (
  <svg className="w-5 h-5" viewBox="0 0 48 48">
    <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039L38.802 6.5C34.522 2.763 29.632 0.5 24 0.5C10.745 0.5 0.5 10.745 0.5 24S10.745 47.5 24 47.5c13.033 0 22.99-9.605 22.99-22.99c0-1.593-0.14-3.15-0.389-4.427z"></path>
    <path fill="#FF3D00" d="M6.306 14.691c-2.413 4.893-3.806 10.426-3.806 16.309C2.5 36.599 7.042 43.1 14.12 46.44c3.483-2.91 5.76-7.393 5.76-12.44s-2.277-9.53-5.76-12.44l-7.814-6.869z"></path>
    <path fill="#4CAF50" d="M24 47.5c5.94 0 11.21-1.808 15.31-4.81l-6.55-5.43c-2.14 1.45-4.84 2.24-7.76 2.24c-5.22 0-9.65-3.34-11.3-7.91l-7.96 6.5C8.81 42.75 15.81 47.5 24 47.5z"></path>
    <path fill="#1976D2" d="M43.611 20.083L43.59 20H24v8h11.303c-0.792 2.237-2.231 4.16-4.087 5.571l6.522 5.38c4.467-4.133 7.266-10.274 7.266-17.433c0-1.593-0.14-3.15-0.389-4.427z"></path>
  </svg>
);
const AadhaarIcon = () => (
    <svg className="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 012-2h2a2 2 0 012 2v1m-6 0h6m-3 6.75a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5zM8 17h8a1 1 0 001-1v-1.5a1 1 0 00-1-1H8a1 1 0 00-1 1V16a1 1 0 001 1z"></path>
    </svg>
);

const API = import.meta.env.VITE_API_BASE_URL;

const SignupPage = () => {
  const [formData, setFormData] = useState({
      name: "",
      age: "",
      region: "",
      phoneNumber: "",
      verificationId: "",
      role: "",
      password: "",
      gender: "",
    });
    const [loading, setLoading] = useState(false);
  
    const roles = ["farmer", "transporter", "processor", "lab", "manufacturer"];
  
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData((prev) => ({ ...prev, [name]: value }));
    };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
  
    // build clean payload
    const payload = {
      ...formData,
      age: Number(formData.age), // ✅ convert to number
    };
  
    if (payload.role === "farmer") {
      delete payload.password; // ✅ don't send empty password
    }
  
    console.log("📦 Final Payload:", payload);
  
    try {
      const res = await fetch(`${API}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
  
      const data = await res.json().catch(() => ({}));
  
      console.log("📥 Response JSON:", data);
  
      if (res.ok) {
        alert(`✅ Registration Successful: ${data.message || "User registered successfully"}`);
        setFormData({
          name: "",
          age: "",
          region: "",
          phoneNumber: "",
          verificationId: "",
          role: "",
          password: "",
          gender: "",
        });
      } else {
        alert(`❌ Error: ${data.message || "Registration failed"}`);
      }
    } catch (err) {
      console.error("🚨 Network error:", err);
      alert("❌ Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-50 p-4 font-sans">
      {/* ✅ Reduced max-width from 6xl to 4xl */}
      <div className="w-full max-w-4xl mx-auto bg-white rounded-2xl shadow-xl grid lg:grid-cols-2">
        
        <div className="hidden lg:block">
          <img
            src={SignupImage}
            alt="A farmer in a field"
            className="w-full h-full object-cover rounded-l-2xl"
          />
        </div>

        {/* ✅ Reduced padding from p-12 to p-8 */}
        <div className="p-8 flex flex-col justify-center">
          <div className="w-full max-w-md mx-auto">
            
            {/* ✅ Reduced margin */}
            <div className="text-right mb-4">
              <p className="text-gray-600">
                Already have an account?{' '}
                <a href="/login" className="font-semibold text-[#133215] hover:underline">
                  Sign In
                </a>
              </p>
            </div>
            
            {/* ✅ Reduced font size and margins */}
            <h2 className="text-3xl font-bold text-[#133215] mb-2">Create Your Account</h2>
            <p className="text-gray-600 mb-6">Join the Sanjeevani network today.</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
              <button className="w-full flex items-center justify-center gap-2 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                <GoogleIcon />
                <span className="font-medium text-gray-700 text-sm">Sign up with Google</span>
              </button>
              <button className="w-full flex items-center justify-center gap-2 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                <AadhaarIcon />
                <span className="font-medium text-gray-700 text-sm">Sign up with Aadhaar</span>
              </button>
            </div>
            
            {/* ✅ Reduced margin */}
            <div className="flex items-center my-6">
              <hr className="flex-grow border-gray-200" />
              <span className="px-3 text-sm text-gray-500">Or continue with email</span>
              <hr className="flex-grow border-gray-200" />
            </div>

            {/* ✅ Reduced gaps */}
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">
              <div className="md:col-span-2">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input id="name" type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-[#92B775] focus:border-[#92B775]" />
              </div>
              
              <div>
                <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">Age</label>
                <input id="age" type="number" name="age" value={formData.age} onChange={handleChange} required className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-[#92B775] focus:border-[#92B775]" />
              </div>
              
              <div>
                <label htmlFor="gender" className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
                <select id="gender" name="gender" value={formData.gender} onChange={handleChange} required className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-[#92B775] focus:border-[#92B775]">
                  <option value="">Select...</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                <input id="phoneNumber" type="tel" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} required className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-[#92B775] focus:border-[#92B775]" />
              </div>

              <div className="md:col-span-2">
                <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">Select Your Role</label>
                <select id="role" name="role" value={formData.role} onChange={handleChange} required className="w-full p-2 border border-gray-300 rounded-md shadow-sm capitalize focus:ring-[#92B775] focus:border-[#92B775]">
                  {roles.map((role) => (
                    <option key={role} value={role} className="capitalize">{role}</option>
                  ))}
                </select>
              </div>
              
              <div className="md:col-span-2">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input id="password" type="password" name="password" value={formData.password} onChange={handleChange} required className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-[#92B775] focus:border-[#92B775]" />
              </div>
              
              {/* ✅ Reduced margin */}
              <div className="md:col-span-2 mt-4">
                <button type="submit" disabled={loading} className="w-full py-2.5 px-4 bg-[#92B775] text-white font-semibold rounded-lg hover:bg-[#82a365] transition-all duration-300 shadow-md disabled:bg-gray-400 flex justify-center items-center">
                  {loading ? 'Creating Account...' : 'Create Account'}
                </button>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;