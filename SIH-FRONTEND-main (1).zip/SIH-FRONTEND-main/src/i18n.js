import i18n from "i18next";
import { initReactI18next } from "react-i18next";

const resources = {
  en: {
    translation: {
      // Header
      title: "Log Your Herb Harvest",
      subtitle: "Fill in the details below to add your produce to the system.",
      incentiveNotice: "Female farmers are eligible for special bonus incentives for their harvest.",
      
      // Form Fields
      herbName: "Herb Name",
      quantityKgs: "Quantity (in Kgs)",
      date: "Harvest Date",
      farmerName: "Farmer Name",
      
      // Location Section
      locationDetails: "Location Details",
      fetchingLocation: "Fetching...",
      getLocation: "Get Current Location",
      latitude: "Latitude",
      longitude: "Longitude",
      address: "Full Address",
      city: "City / District",
      state: "State",
      pincode: "Pincode",
      country: "Country",

      // Buttons & Statuses
      uploading: "Uploading...",
      submit: "Submit Harvest",
      success: "Harvest Logged Successfully!",
      successAlert: "Harvest logged successfully!",
      openLink: "View Transaction Details",
    },
  },
  hi: {
    translation: {
      // Header
      title: "अपनी जड़ी-बूटी की फसल दर्ज करें",
      subtitle: "सिस्टम में अपनी उपज जोड़ने के लिए नीचे दिए गए विवरण भरें।",
      incentiveNotice: "महिला किसान अपनी फसल के लिए विशेष बोनस प्रोत्साहन के लिए पात्र हैं।",

      // Form Fields
      herbName: "जड़ी-बूटी का नाम",
      quantityKgs: "मात्रा (किलोग्राम में)",
      date: "कटाई की तारीख",
      farmerName: "किसान का नाम",

      // Location Section
      locationDetails: "स्थान का विवरण",
      fetchingLocation: "ढूंढ रहा है...",
      getLocation: "वर्तमान स्थान प्राप्त करें",
      latitude: "अक्षांश",
      longitude: "देशांतर",
      address: "पूरा पता",
      city: "शहर / जिला",
      state: "राज्य",
      pincode: "पिनकोड",
      country: "देश",
      
      // Buttons & Statuses
      uploading: "अपलोड हो रहा है...",
      submit: "फसल जमा करें",
      success: "फसल सफलतापूर्वक दर्ज की गई!",
      successAlert: "फसल सफलतापूर्वक दर्ज हो गई!",
      openLink: "लेन-देन का विवरण देखें",
    },
  },
};

i18n.use(initReactI18next).init({
  resources,
  lng: "en", // default language
  interpolation: { escapeValue: false },
});

export default i18n;




// import i18n from "i18next";
// import { initReactI18next } from "react-i18next";

// const resources = {
//   en: {
//     translation: {
//       title: "Upload Herb Data",
//       herbName: "Herb Name",
//       date: "Date",
//       quantity: "Quantity",
//       city: "City",
//       address: "Address",
//       county: "County",
//       pincode: "Pincode",
//       farmerId: "Farmer ID",
//       submit: "Submit",
//       uploading: "Uploading...",
//       success: "Herb uploaded successfully!",
//       openLink: "Open Herb Link",
//     },
//   },
//   hi: {
//     translation: {
//       title: "जड़ी-बूटी डेटा अपलोड करें",
//       herbName: "जड़ी-बूटी का नाम",
//       date: "तारीख",
//       quantityKgs: "मात्रा (किलोग्राम)",
//       city: "शहर",
//       address: "पता",
//       county: "ज़िला",
//       pincode: "पिनकोड",
//       farmerId: "किसान आईडी",
//       submit: "जमा करें",
//       uploading: "अपलोड हो रहा है...",
//       success: "जड़ी-बूटी सफलतापूर्वक अपलोड हो गई!",
//       openLink: "जड़ी-बूटी लिंक खोलें",
//     },
//   },
// };

// i18n.use(initReactI18next).init({
//   resources,
//   lng: "en", // default language
//   interpolation: { escapeValue: false },
// });

// export default i18n;
