import React, { useEffect, useState } from "react";
import { Star } from "lucide-react";



// const [rating, setrating] = useState();
// --- Helper Components for Icons (Combined from both files) ---

const UserIcon = (props) => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>;
const CalendarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const LocationIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const PhoneIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>;
const IdIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4z" /></svg>;
const RoleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197m0 0A10.99 10.99 0 0012 12c2.67 0 5.117.933 7 2.405" /></svg>;
// Icons for Stat Cards from the second file
const HerbIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M20.625 15.586a2.25 2.25 0 01-3.182 0l-3.535-3.536a2.25 2.25 0 010-3.182l.354-.353a2.25 2.25 0 013.182 0l3.536 3.536a2.25 2.25 0 010 3.182z" /><path strokeLinecap="round" strokeLinejoin="round" d="M10.939 10.939a2.25 2.25 0 010-3.182l3.182-3.182a2.25 2.25 0 013.182 0l.354.354a2.25 2.25 0 010 3.182l-3.182 3.182a2.25 2.25 0 01-3.182 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M10.232 17.382a2.25 2.25 0 01-3.182 0l-3.182-3.182a2.25 2.25 0 010-3.182l.354-.354a2.25 2.25 0 013.182 0l3.182 3.182a2.25 2.25 0 010 3.182z" /></svg>;
const WeightIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 17.25a4.5 4.5 0 01-4.5-4.5v-1.5a4.5 4.5 0 014.5-4.5h8.25a4.5 4.5 0 014.5 4.5v1.5a4.5 4.5 0 01-4.5 4.5H8z" /></svg>;
const CheckListIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;




const StatCard = ({ title, value, icon, unit = '' }) => (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 flex items-center space-x-4">
        <div className="flex-shrink-0">{icon}</div>
        <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className="text-2xl font-bold text-gray-800">{value} <span className="text-lg font-medium text-gray-600">{unit}</span></p>
        </div>
    </div>
);

const InfoItem = ({ icon, label, value }) => (
    <div className="flex items-start space-x-3">
        <div className="flex-shrink-0 pt-1">{icon}</div>
        <div>
            <p className="text-sm font-medium text-gray-500">{label}</p>
            <p className="text-md font-semibold text-gray-800">{value}</p>
        </div>
    </div>
);

const API = import.meta.env.VITE_API_BASE_URL;

const Dashboard = ({ user }) => {
    // State management from the first file
    const [userData, setUserData] = useState(null);
    const [blocks, setBlocks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [rating, setRating] = useState(null);

    // Data fetching logic from the first file - UNCHANGED
    useEffect(() => {
        if (!user) {
            setLoading(false);
            setError("User not found. Please log in.");
            return;
        }

        const fetchDashboard = async () => {
            setLoading(true);
            try {
                const res = await fetch(`${API}/dashboard/${user.role}/${user._id}`);
                const data = await res.json();

                if (res.ok && data.success) {
                    setUserData(data.user);
                    setBlocks(data.blocks);
                } else {
                    setError(data.error || "Failed to fetch dashboard data.");
                }
            } catch (err) {
                setError("An unexpected error occurred.");
                console.error("Fetch error:", err);
            } finally {
                setLoading(false);
            }
        };

        fetchDashboard();
    }, [user]);

    // Loading and Error states from the first file
    if (loading) {
        return (
            <div className="flex justify-center items-center min-h-screen bg-gray-50">
                <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-[#92B775]"></div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex justify-center items-center min-h-screen bg-gray-50 p-4">
                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md shadow-md" role="alert">
                    <p className="font-bold">Error</p>
                    <p>{error}</p>
                </div>
            </div>
        );
    }
    
    if (!userData) {
        return null; // or a message indicating no user data
    }

   

// ⭐ Badge System
const getBadge = () => {
  if (!rating) return "🌱 Beginner";

  const r = Number(rating);

  if (r >= 9) return "🥇 Gold Farmer";
  if (r >= 7) return "🥈 Silver Farmer";
  if (r >= 5) return "🥉 Bronze Farmer";

  return "🌱 Beginner";
};


    // --- Derived State for Stat Cards (calculated from fetched data) ---
    const totalQuantity = blocks.reduce((sum, block) => sum + (block.data.quantity || 0), 0);
    const uniqueHerbs = new Set(blocks.map(block => block.data.herbName)).size;
    const lastActivityDate = blocks.length > 0 ? new Date(blocks[blocks.length - 1].timestamp).toLocaleDateString() : 'N/A';
    
    // --- Render JSX using the layout from the second file ---
    return (
        <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
            <main className="container mx-auto px-4 py-12">
                <h1 className="text-3xl md:text-4xl font-bold text-[#133215] mb-4 capitalize">
                    {user?.role} Dashboard
                </h1>
                <p className="text-gray-500 mb-8">Welcome back, {userData.name}. Here's an overview of your activity.</p>
                
                {/* --- Stats Section from second file --- */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    
                    <StatCard title="Total Herbs Logged" value={blocks.length} icon={<CheckListIcon />} />
                    <StatCard title="Total Quantity" value={totalQuantity} unit="kg" icon={<WeightIcon />} />
                    <StatCard title="Unique Herb Types" value={uniqueHerbs} icon={<HerbIcon />} />
                    <StatCard title="Last Activity" value={lastActivityDate} icon={<CalendarIcon />} />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* --- Profile Section (enhanced layout from second file) --- */}
                    <div className="lg:col-span-1">
                        <div className="bg-white p-6 rounded-xl shadow-lg sticky top-8">
                            <div className="flex flex-col items-center mb-6 text-center">
                                <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center mb-4">
                                    <UserIcon className="w-12 h-12 text-gray-500" />
                                </div>
                                <h2 className="text-2xl font-bold text-[#133215]">{userData.name}</h2>
                           {/* ⭐ Rating + Badge */}
<div className="flex flex-col items-center mt-1">
  <div className="flex items-center gap-1 text-yellow-500">
    <Star size={16} fill="currentColor" />
    <span className="text-sm">{rating || "N/A"}</span>
  </div>

  <p className="text-xs font-semibold text-gray-600">
    {getBadge()}
  </p>
</div>




                            </div>
                            <div className="space-y-4">
                                <InfoItem icon={<LocationIcon />} label="Region" value={userData.region} />
                                <InfoItem icon={<PhoneIcon />} label="Phone" value={userData.phoneNumber} />
                                <InfoItem icon={<RoleIcon />} label="Role" value={userData.role} />
                                <InfoItem icon={<CalendarIcon />} label="Age" value={`${userData.age} years`} />
                                <InfoItem icon={<IdIcon />} label="Verification ID" value={userData.verificationId} />
                            </div>
                        </div>
                    </div>

                    {/* --- Activity Section (table layout from second file) --- */}
                    <div className="lg:col-span-2">
                        <div className="bg-white p-6 rounded-xl shadow-lg">
                            <h2 className="text-2xl font-bold text-[#133215] mb-6">Activity Log</h2>
                            {blocks.length > 0 ? (
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead className="bg-gray-50">
                                            <tr>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Herb Name</th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity (kg)</th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Logged</th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-200">
                                            {blocks.map(block => (
                                                <tr key={block.index} className="hover:bg-gray-50 transition-colors">
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{block.data.herbName || 'N/A'}</td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{block.data.quantity || 'N/A'}</td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{new Date(block.timestamp).toLocaleDateString()}</td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                            Verified
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ) : (
                                <div className="text-center py-10 px-6 bg-gray-50 rounded-lg">
                                    <p className="text-sm text-gray-500">No blockchain activity to display.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Dashboard;