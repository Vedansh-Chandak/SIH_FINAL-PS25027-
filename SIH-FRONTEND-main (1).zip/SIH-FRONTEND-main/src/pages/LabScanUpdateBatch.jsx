import React, { useEffect, useState, useRef } from "react";
import { Html5QrcodeScanner } from "html5-qrcode";
import QRCode from "qrcode";
import { Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";

// --- Chart.js Registration ---
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

// --- Environment & Constants ---
const API = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";
const CERTIFICATE_OPTIONS = ["ISO 9001", "GMP Certified", "Organic Certified"];

// --- Reusable UI Components ---
const StyledInput = ({ name, id, type = "text", value, onChange, placeholder, required, readOnly = false }) => (
  <input
    type={type}
    name={name}
    id={id}
    value={value}
    onChange={onChange}
    placeholder={placeholder}
    required={required}
    readOnly={readOnly}
    className={`w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-[#92B775] focus:border-[#92B775] ${readOnly ? 'bg-gray-100 cursor-not-allowed' : ''}`}
  />
);

// --- Chart Components ---
const LabCharts = ({ data }) => {
  const chartData = {
    labels: ["Moisture (%)", "Purity (%)", "Pesticide (%)", "Active Comp. (%)"],
    datasets: [
      {
        label: "Lab Analysis Results",
        data: [
          data.moistureContent || 0,
          data.purityLevel || 0,
          data.pesticideLevel || 0,
          data.activeCompoundLevel || 0,
        ],
        backgroundColor: [
          "rgba(54, 162, 235, 0.6)", // Blue
          "rgba(75, 192, 192, 0.6)", // Green
          "rgba(255, 99, 132, 0.6)", // Red
          "rgba(255, 206, 86, 0.6)", // Yellow
        ],
        borderColor: [
          "rgba(54, 162, 235, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(255, 99, 132, 1)",
          "rgba(255, 206, 86, 1)",
        ],
        borderWidth: 1,
      },
    ],
  };

  const barOptions = {
    responsive: true,
    plugins: { legend: { position: "top" }, title: { display: true, text: "Lab Metrics (Bar Chart)" } },
    scales: { y: { beginAtZero: true, max: 100 } }
  };
  
  const pieOptions = {
    responsive: true,
    plugins: { legend: { position: 'top' }, title: { display: true, text: 'Lab Metrics (Pie Chart)' } },
  };


  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
      <div className="bg-white p-4 rounded-lg shadow-md">
        <Bar options={barOptions} data={chartData} />
      </div>
       <div className="bg-white p-4 rounded-lg shadow-md flex justify-center items-center" style={{maxHeight: '400px'}}>
        <Pie data={chartData} options={pieOptions} />
      </div>
    </div>
  );
};


const LabScanUpdateBatch = ({ user }) => {
  const [processing, setProcessing] = useState(null);
  const [link, setLink] = useState("");
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(false);
  const [qrImage, setQrImage] = useState("");
  const [qrLink, setQrLink] = useState("");

  const [isScannerVisible, setIsScannerVisible] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const scannerRef = useRef(null);
  const scannerContainerId = "reader";

  // --- Scanner Control ---
  const startScanner = () => {
    if (scannerRef.current) return;
    const scanner = new Html5QrcodeScanner(scannerContainerId, { fps: 10, qrbox: { width: 250, height: 250 } });
    scanner.render(
      (decodedText) => {
        stopScanner();
        if (decodedText.includes("/processing/")) {
          fetchProcessing(extractIdFromUrl(decodedText));
        } else {
          alert("Invalid QR Code: Please scan a valid processing QR code.");
        }
      },
      () => {}
    );
    scannerRef.current = scanner;
    setIsScanning(true);
  };

  const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.clear().finally(() => {
        scannerRef.current = null;
        setIsScanning(false);
      });
    }
  };
  
  // --- Data Handling ---
  const fetchProcessing = async (id) => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/processing/${id}`);
      const data = await res.json();
      if (!data.success) throw new Error("Processing record not found");
      setProcessing(data.processing);
      setFormData({
        ...data.processing,
        labName: "",
        qualityAssurance: "Passed", // Default value
        certificates: [],
        moistureContent: "",
        purityLevel: "",
        pesticideLevel: "",
        activeCompoundLevel: "",
      });
      setIsScannerVisible(false);
    } catch (err) {
      alert(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const extractIdFromUrl = (url) => (url.split("/").pop() || url.split("/").slice(-2, -1)[0]);

  const handleLinkSubmit = (e) => {
    e.preventDefault();
    if (link) fetchProcessing(extractIdFromUrl(link));
  };
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      setFormData((prev) => ({
        ...prev,
        certificates: checked
          ? [...(prev.certificates || []), value]
          : prev.certificates.filter((c) => c !== value),
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleLabSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        // Carry over all previous data
        ...processing, 
        // Add new lab data
        labName: formData.labName,
        qualityAssurance: formData.qualityAssurance,
        certificates: formData.certificates,
        moistureContent: Number(formData.moistureContent) || 0,
        purityLevel: Number(formData.purityLevel) || 0,
        pesticideLevel: Number(formData.pesticideLevel) || 0,
        activeCompoundLevel: Number(formData.activeCompoundLevel) || 0,
      };
      
      const res = await fetch(`${API}/lab`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.message || "Submission failed");
      
      const labId = data.labProcessing._id;
      const qrPayload = `${window.location.origin}/lab/${labId}`;
      const qrDataUrl = await QRCode.toDataURL(qrPayload);

      await fetch(`${API}/lab/${labId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ qrPayload, qrImage: qrDataUrl })
      });

      setQrImage(qrDataUrl);
      setQrLink(qrPayload);
      alert("Lab data submitted successfully!");

    } catch (err) {
      alert(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => () => { if (scannerRef.current) stopScanner() }, []);

  if (user.role !== "lab") return <div className="text-center p-10"><h1 className="text-2xl font-bold text-red-600">Access Denied</h1></div>;

  return (
    <div className="flex flex-col items-center p-4 md:p-6 bg-gray-50 min-h-screen">
      {isScannerVisible ? (
        <div className="w-full max-w-lg mx-auto text-center">
          <h1 className="text-3xl font-bold text-[#133215] mb-2">Scan Processing QR Code</h1>
          <p className="text-gray-600 mb-6">Press "Start Scanning" to open the camera.</p>
          <div id={scannerContainerId} className="w-full bg-white p-2 border border-white rounded-xl  mb-4" />
          {!isScanning ? (
            <button onClick={startScanner} className="w-full px-6 py-3 bg-[#92B775] text-white font-semibold rounded-md hover:bg-[#82a365]">Start Scanning</button>
          ) : (
            <button onClick={stopScanner} className="w-full px-6 py-3 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700]">Stop Scanning</button>
          )}
          <div className="flex items-center my-4"><hr className="flex-grow"/><span className="px-4 text-gray-500">OR</span><hr className="flex-grow"/></div>
          <form onSubmit={handleLinkSubmit} className="w-full flex gap-2 ">
            <input type="text" placeholder="Paste processing link here" value={link} onChange={(e) => setLink(e.target.value)} className="flex-1 border border-gray-300 rounded-md focus:ring-[#92B775]"/>
            <button type="submit" disabled={loading} className="bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700">{loading ? "..." : "Fetch"}</button>
          </form>
        </div>
      ) : processing && (
        <main className="w-full flex-grow container mx-auto">
          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-xl shadow-2xl">
            <h2 className="text-3xl font-bold text-[#133215] mb-2 text-center">Update Lab Analysis</h2>
            <p className="text-center text-gray-600 mb-8">Enter the quality analysis data for the processed batch.</p>
            
            <div className="mb-8 p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Original Processing Details</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div><p className="font-medium text-gray-500">Herb</p><p className="font-semibold">{processing.herbName}</p></div>
                <div><p className="font-medium text-gray-500">Farmer</p><p className="font-semibold">{processing.farmerName}</p></div>
                <div><p className="font-medium text-gray-500">Unit Name</p><p className="font-semibold">{processing.processingUnitName}</p></div>
                <div><p className="font-medium text-gray-500">Processes</p><p className="font-semibold">{processing.processes?.join(", ")}</p></div>
              </div>
            </div>

            <form onSubmit={handleLabSubmit}>
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Lab Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-1">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Lab Name</label>
                    <StyledInput name="labName" placeholder="e.g., Central Herbal Lab" value={formData.labName} onChange={handleChange} required />
                  </div>
                  <div className="md:col-span-1">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Quality Assurance</label>
                    <select name="qualityAssurance" value={formData.qualityAssurance} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-[#92B775]">
                      <option>Passed</option>
                      <option>Failed</option>
                      <option>Pending</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Certificates</label>
                    <div className="grid grid-cols-3 gap-4 p-4 border rounded-md bg-gray-50">
                      {CERTIFICATE_OPTIONS.map((cert) => (
                        <label key={cert} className="flex items-center gap-3 cursor-pointer">
                          <input type="checkbox" name="certificates" value={cert} checked={formData.certificates?.includes(cert)} onChange={handleChange} className="h-4 w-4 rounded"/>
                          <span>{cert}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="md:col-span-2 border-t pt-6 mt-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Test Results (%)</h3>
                 <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div><label className="block text-sm font-medium">Moisture Content</label><StyledInput name="moistureContent" type="number" placeholder="e.g., 8.5" value={formData.moistureContent} onChange={handleChange} required /></div>
                    <div><label className="block text-sm font-medium">Purity Level</label><StyledInput name="purityLevel" type="number" placeholder="e.g., 99.2" value={formData.purityLevel} onChange={handleChange} required /></div>
                    <div><label className="block text-sm font-medium">Pesticide Level</label><StyledInput name="pesticideLevel" type="number" placeholder="e.g., 0.1" value={formData.pesticideLevel} onChange={handleChange} required /></div>
                    <div><label className="block text-sm font-medium">Active Compound</label><StyledInput name="activeCompoundLevel" type="number" placeholder="e.g., 2.4" value={formData.activeCompoundLevel} onChange={handleChange} required /></div>
                 </div>
              </div>

              <div className="md:col-span-2 text-center mt-8">
                <button type="submit" disabled={loading || qrImage} className="w-full md:w-auto px-12 py-3 bg-[#92B775] text-white font-bold rounded-lg hover:bg-[#82a365] disabled:bg-gray-400">
                  {loading ? "Submitting..." : "Submit & Generate QR"}
                </button>
              </div>
            </form>
            
            {/* Live charts are rendered here */}
            <div className="mt-10 pt-6 border-t">
                 <LabCharts data={formData} />
            </div>

            {qrImage && (
              <div className="mt-10 pt-6 border-t flex flex-col items-center gap-4">
                <h3 className="text-xl font-semibold text-[#133215]">New Lab QR Code</h3>
                <img src={qrImage} alt="Generated Lab QR Code" className="w-48 h-48 border p-1" />
                <a href={qrLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline hover:text-blue-800">Open Lab Link</a>
                <a href={qrImage} download={`lab-qr-${processing.herbName}.png`} className="px-4 py-2 bg-gray-700 text-white text-sm rounded-md hover:bg-gray-800">Download QR Code</a>
              </div>
            )}
          </div>
        </main>
      )}
    </div>
  );
};

export default LabScanUpdateBatch;