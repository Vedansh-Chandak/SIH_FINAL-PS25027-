import React, { useEffect, useState, useRef } from "react";
import { Html5QrcodeScanner } from "html5-qrcode";
import QRCode from "qrcode";
import { Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";

// --- Chart.js Registration ---
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

// --- Environment & Constants ---
const API = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";
const FRONTEND = import.meta.env.VITE_FRONTEND || "http://localhost:5173";
const STATUS_FIELDS = ["Collected", "Processed", "Lab Verified", "Dispatched"];

// --- Reusable UI Components ---
const StyledInput = ({ name, id, type = "text", value, onChange, placeholder, required, readOnly = false }) => (
  <input
    type={type}
    name={name}
    id={id}
    value={value}
    onChange={onChange}
    placeholder={placeholder}
    required={required}
    readOnly={readOnly}
    className={`w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-[#92B775] focus:border-[#92B775] ${readOnly ? 'bg-gray-100 cursor-not-allowed' : ''}`}
  />
);

// --- Chart Components ---
const LabCharts = ({ data }) => {
  const chartData = {
    labels: ["Moisture (%)", "Purity (%)", "Pesticide (%)", "Active Comp. (%)"],
    datasets: [
      {
        label: "Lab Analysis Results",
        data: [
          data.moistureContent || 0,
          data.purityLevel || 0,
          data.pesticideLevel || 0,
          data.activeCompoundLevel || 0,
        ],
        backgroundColor: ["rgba(54, 162, 235, 0.6)", "rgba(75, 192, 192, 0.6)", "rgba(255, 99, 132, 0.6)", "rgba(255, 206, 86, 0.6)"],
        borderColor: ["rgba(54, 162, 235, 1)", "rgba(75, 192, 192, 1)", "rgba(255, 99, 132, 1)", "rgba(255, 206, 86, 1)"],
        borderWidth: 1,
      },
    ],
  };
  const barOptions = {
    responsive: true,
    plugins: { legend: { position: "top" }, title: { display: true, text: "Lab Metrics Summary (Bar Chart)" } },
    scales: { y: { beginAtZero: true, max: 100 } },
  };
  const pieOptions = {
    responsive: true,
    plugins: { legend: { position: 'top' }, title: { display: true, text: 'Lab Metrics Composition (Pie Chart)' } },
  };
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
      <div className="bg-white p-4 rounded-lg shadow-md"><Bar options={barOptions} data={chartData} /></div>
      <div className="bg-white p-4 rounded-lg shadow-md flex justify-center items-center" style={{ maxHeight: '400px' }}><Pie data={chartData} options={pieOptions} /></div>
    </div>
  );
};

const ManufactureScanUpdatePage = ({ user }) => {
  const [labData, setLabData] = useState(null);
  const [link, setLink] = useState("");
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(false);
  const [qrImage, setQrImage] = useState("");
  const [qrLink, setQrLink] = useState("");

  const [isScannerVisible, setIsScannerVisible] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const scannerRef = useRef(null);
  const scannerContainerId = "reader";

  // --- Scanner Control ---
  const startScanner = () => {
    if (scannerRef.current) return;
    const scanner = new Html5QrcodeScanner(scannerContainerId, { fps: 10, qrbox: { width: 250, height: 250 } });
    scanner.render(
      (decodedText) => {
        stopScanner();
        if (decodedText.includes("/lab/")) {
          fetchLabData(extractIdFromUrl(decodedText));
        } else {
          alert("Invalid QR Code: Please scan a valid Lab QR code.");
        }
      },
      () => {}
    );
    scannerRef.current = scanner;
    setIsScanning(true);
  };

  const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.clear().finally(() => {
        scannerRef.current = null;
        setIsScanning(false);
      });
    }
  };

  // --- Data Handling ---
  const fetchLabData = async (id) => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/lab/${id}`);
      const data = await res.json();
      if (!data.success) throw new Error("Lab data not found");
      setLabData(data.labProcessing);
      // ✅ **UPDATED STATE:** Added companyName and manufactureDate
      setFormData({
        ...data.labProcessing,
        collected: false,
        processed: false,
        labVerified: false,
        dispatched: false,
        companyName: "",
        productName: "",
        manufactureDate: ""
      });
      setIsScannerVisible(false);
    } catch (err) {
      alert(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };
  
  const extractIdFromUrl = (url) => (url.split("/").pop() || url.split("/").slice(-2, -1)[0]);

  const handleLinkSubmit = (e) => {
    e.preventDefault();
    if (link) fetchLabData(extractIdFromUrl(link));
  };
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = { ...formData };
      const res = await fetch(`${API}/manufacture`, {
        method: 'POST', headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.message || "Submission failed");
      
      const manId = data.manufactureSchema._id;
      const qrPayload = `${FRONTEND}/consumer/${manId}`;
      const qrDataUrl = await QRCode.toDataURL(qrPayload);
      
      await fetch(`${API}/manufacture/${manId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ qrPayload, qrImage: qrDataUrl })
      });

      setQrImage(qrDataUrl);
      setQrLink(qrPayload);
      alert("Manufacturing data submitted successfully!");
    } catch (err) {
      alert(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => () => { if (scannerRef.current) stopScanner() }, []);

  if (user.role !== "manufacturer") return <div className="text-center p-10"><h1 className="text-2xl font-bold text-red-600">Access Denied</h1></div>;

  return (
    <div className="flex flex-col items-center p-4 md:p-6 bg-gray-50 min-h-screen">
      {isScannerVisible ? (
        <div className="w-full max-w-lg mx-auto text-center">
          <h1 className="text-3xl font-bold text-[#133215] mb-2">Scan Lab QR Code</h1>
          <p className="text-gray-600 mb-6">Press "Start Scanning" to open the camera.</p>
          <div id={scannerContainerId} className="w-full bg-white p-2  rounded-xl  mb-4" />
          {!isScanning ? (
            <button onClick={startScanner} className="w-full px-6 py-3 bg-[#92B775] text-white font-semibold rounded-md hover:bg-[#82a365]">Start Scanning</button>
          ) : (
            <button onClick={stopScanner} className="w-full px-6 py-3 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700]">Stop Scanning</button>
          )}
          <div className="flex items-center my-4"><hr className="flex-grow"/><span className="px-4 text-gray-500">OR</span><hr className="flex-grow"/></div>
          <form onSubmit={handleLinkSubmit} className="w-full flex gap-2">
            <input type="text" placeholder="Paste lab link here" value={link} onChange={(e) => setLink(e.target.value)} className="flex-1 border-gray-300 rounded-md border focus:ring-[#92B775]"/>
            <button type="submit" disabled={loading} className="bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700">{loading ? "..." : "Fetch"}</button>
          </form>
        </div>
      ) : labData && (
        <main className="w-full flex-grow container mx-auto">
          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-xl shadow-2xl">
            <h2 className="text-3xl font-bold text-[#133215] mb-2 text-center">Final Product Manufacturing</h2>
            <p className="text-center text-gray-600 mb-8">Review the complete product journey and generate the final consumer QR code.</p>
            
            <div className="space-y-8">
              {/* History blocks */}
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg"><h3 className="text-lg font-semibold text-gray-800 mb-4">🌱 Farmer & Herb Details</h3><div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm"><div><p className="font-medium text-gray-500">Herb</p><p className="font-semibold">{labData.herbName}</p></div><div><p className="font-medium text-gray-500">Farmer</p><p className="font-semibold">{labData.farmerName}</p></div><div><p className="font-medium text-gray-500">Origin City</p><p className="font-semibold">{labData.city}</p></div><div><p className="font-medium text-gray-500">Harvest Date</p><p className="font-semibold">{new Date(labData.date).toLocaleDateString()}</p></div></div></div>
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg"><h3 className="text-lg font-semibold text-gray-800 mb-4">🚚 Transport Details</h3><div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm"><div><p className="font-medium text-gray-500">Driver</p><p className="font-semibold">{labData.driverName}</p></div><div><p className="font-medium text-gray-500">Vehicle</p><p className="font-semibold">{labData.vehicleNumber}</p></div><div><p className="font-medium text-gray-500">Destination</p><p className="font-semibold">{labData.transportCity}</p></div><div><p className="font-medium text-gray-500">Quantity (g)</p><p className="font-semibold">{labData.transportQuantity}</p></div></div></div>
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg"><h3 className="text-lg font-semibold text-gray-800 mb-4">⚙️ Processor Details</h3><div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm"><div className="md:col-span-2"><p className="font-medium text-gray-500">Unit Name</p><p className="font-semibold">{labData.processingUnitName}</p></div><div className="md:col-span-2"><p className="font-medium text-gray-500">Processes</p><p className="font-semibold">{labData.processes?.join(", ")}</p></div></div></div>
              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg"><h3 className="text-lg font-semibold text-gray-800 mb-4">🔬 Lab Details</h3><div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm"><div><p className="font-medium text-gray-500">Lab</p><p className="font-semibold">{labData.labName}</p></div><div><p className="font-medium text-gray-500">QA Status</p><p className="font-semibold text-green-600">{labData.qualityAssurance}</p></div><div className="md:col-span-2"><p className="font-medium text-gray-500">Certificates</p><p className="font-semibold">{labData.certificates?.join(", ")}</p></div></div></div>
            </div>
              <div className="mt-10 pt-6 border-t"><h3 className="text-xl font-semibold text-center text-gray-800 mb-4">Lab Analysis Visualized</h3><LabCharts data={labData} /></div>
            
            {/* Manufacturer Form */}
            <form onSubmit={handleSubmit} className="mt-8">
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Manufacturer Details & Status</h3>
                
                {/* ✅ **UPDATED FORM:** Added new fields */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div>
                        <label className="block text-sm font-medium">Company Name</label>
                        <StyledInput name="companyName" placeholder="e.g., AyurHerbs Pvt. Ltd." value={formData.companyName} onChange={handleChange} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">Final Product Name</label>
                        <StyledInput name="productName" placeholder="e.g., Tulsi Immunity Drops" value={formData.productName} onChange={handleChange} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">Manufacture Date</label>
                        <StyledInput name="manufactureDate" type="date" value={formData.manufactureDate} onChange={handleChange} required />
                    </div>
                </div>

                <h3 className="text-lg font-semibold text-gray-800 mb-4">Manufacturing Status Checklist</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 border rounded-md bg-gray-50">
                    {STATUS_FIELDS.map((field) => {
                        const fieldName = field.charAt(0).toLowerCase() + field.slice(1).replace(" ", "");
                        return (
                        <label key={fieldName} className="flex items-center gap-3 cursor-pointer">
                            <input type="checkbox" name={fieldName} checked={formData[fieldName] || false} onChange={handleChange} className="h-5 w-5 rounded"/>
                            <span className="font-medium text-gray-800">{field}</span>
                        </label>
                        );
                    })}
                </div>
              </div>

              <div className="text-center mt-8">
                <button type="submit" disabled={loading || qrImage} className="w-full md:w-auto px-12 py-3 bg-[#92B775] text-white font-bold rounded-lg hover:bg-[#82a365] disabled:bg-gray-400">
                  {loading ? "Submitting..." : "Submit & Generate Consumer QR"}
                </button>
              </div>
            </form>
            
            {qrImage && (
              <div className="mt-10 pt-6 border-t flex flex-col items-center gap-4">
                <h3 className="text-xl font-semibold text-[#133215]">Final Consumer QR Code</h3>
                <img src={qrImage} alt="Generated Consumer QR Code" className="w-48 h-48 border p-1" />
                <a href={qrLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline hover:text-blue-800">Open Consumer Link</a>
                <a href={qrImage} download={`consumer-qr-${labData.herbName}.png`} className="px-4 py-2 bg-gray-700 text-white text-sm rounded-md hover:bg-gray-800">Download QR Code</a>
              </div>
            )}
          </div>
        </main>
      )}
    </div>
  );
};

export default ManufactureScanUpdatePage;