import React, { useEffect, useState } from "react";
import { QRCodeSVG } from "qrcode.react";

const API = import.meta.env.VITE_API_BASE_URL;
const FRONTEND = import.meta.env.VITE_FRONTEND;

const MyBatches = ({ user }) => {
  const [batches, setBatches] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedBatch, setSelectedBatch] = useState(null);

  const rowsPerPage = 6;

  useEffect(() => {
    if (!user) return;
    const fetchBatches = async () => {
      try {
        const response = await fetch(
          `${API}/api/users/farmer/${user._id}/blocks`
        );
        const data = await response.json();

        // Map to extract `data` from each block
        const formatted = data.map((block) => ({
          ...block.data,
          hash: block.hash, // keep hash for QR
        }));

        setBatches(formatted);
      } catch (error) {
        console.error("Error fetching batches:", error);
      }
    };
    fetchBatches();
  }, [user]);

  // Pagination
  const totalPages = Math.ceil(batches.length / rowsPerPage);
  const startIndex = (currentPage - 1) * rowsPerPage;
  const currentBatches = batches.slice(startIndex, startIndex + rowsPerPage);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-extrabold text-gray-800 mb-4">
        🌿 My Herb Batches
      </h1>
      <p className="text-gray-600 mb-6">
        Below is the list of herb batches submitted by the farmer.
      </p>

      {/* Table */}
      <div className="overflow-x-auto bg-white rounded-2xl shadow-lg">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-green-700 text-white">
              <th className="px-4 py-3">#</th>
              <th className="px-4 py-3">Herb Name</th>
              <th className="px-4 py-3">Quantity (kg)</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Location</th>
              <th className="px-4 py-3 text-center">View</th>
            </tr>
          </thead>
          <tbody>
            {currentBatches.length > 0 ? (
              currentBatches.map((batch, index) => (
                <tr
                  key={batch.hash}
                  className={`border-b hover:bg-gray-50 transition ${
                    index % 2 === 0 ? "bg-gray-50" : "bg-white"
                  }`}
                >
                  <td className="px-4 py-3 font-semibold text-gray-700">
                    {startIndex + index + 1}
                  </td>
                  <td className="px-4 py-3">{batch.herbName}</td>
                  <td className="px-4 py-3">{batch.quantity}</td>
                  <td className="px-4 py-3">
                    {new Date(batch.date).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3">
                    📍 {batch.geoLocation.lat.toFixed(3)},{" "}
                    {batch.geoLocation.long.toFixed(3)}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button
                      onClick={() => setSelectedBatch(batch)}
                      className="text-green-700 hover:text-green-900"
                    >
                      {/* Eye SVG */}
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="w-6 h-6 inline-block"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 
                          4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                        />
                      </svg>
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" className="px-4 py-6 text-center text-gray-500">
                  No batches available yet 🚫
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex justify-between items-center mt-4">
        <button
          onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
          disabled={currentPage === 1}
          className="px-4 py-2 bg-gray-200 rounded-md disabled:opacity-50"
        >
          ⬅ Previous
        </button>
        <span className="text-gray-600">
          Page {currentPage} of {totalPages}
        </span>
        <button
          onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
          disabled={currentPage === totalPages}
          className="px-4 py-2 bg-gray-200 rounded-md disabled:opacity-50"
        >
          Next ➡
        </button>
      </div>

      {/* Modal for QR */}
      {selectedBatch && (
        <div className="fixed inset-0 bg-black/80 flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-xl p-6 max-w-md w-full relative flex flex-col items-center">
            <button
              onClick={() => setSelectedBatch(null)}
              className="absolute top-2 right-3 text-gray-500 hover:text-gray-800"
            >
              ✖
            </button>

            <h2 className="text-xl font-bold mb-4 text-green-700">
              🌿 Scan QR for Herb
            </h2>

            {/* QR Code */}
            <QRCodeSVG
              value={`${FRONTEND}/${selectedBatch.hash}`}
              size={220}
            />

            {/* Link below QR */}
            <a
              href={`${FRONTEND}/${selectedBatch.hash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 text-green-700 underline"
            >
              Open Herb Details
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyBatches;
