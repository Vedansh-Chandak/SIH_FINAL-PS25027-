import React, { useEffect, useState, useRef, useCallback } from "react";
import { Html5QrcodeScanner } from "html5-qrcode";
import QRCode from "qrcode";

// --- Environment Variables ---
const API = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";

// --- Reusable UI Components ---
const StyledInput = ({ name, id, type = "text", value, onChange, placeholder, required, readOnly = false }) => (
  <input
    type={type}
    name={name}
    id={id}
    value={value}
    onChange={onChange}
    placeholder={placeholder}
    required={required}
    readOnly={readOnly}
    className={`w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-[#92B775] focus:border-[#92B775] ${readOnly ? 'bg-gray-100 cursor-not-allowed' : ''}`}
  />
);

const ScanUpdateBatch = ({ user }) => {
  const [herb, setHerb] = useState(null);
  const [qrImage, setQrImage] = useState("");
  const [qrLink, setQrLink] = useState("");
  const [link, setLink] = useState("");
  const [formData, setFormData] = useState({
      transportGeoLocation: { lat: "", long: "" },
      transportCity: "",
      transportPincode: "",
  });
  const [loading, setLoading] = useState(false);
  const [isScannerActive, setIsScannerActive] = useState(true);

  const [isScanning, setIsScanning] = useState(false);
  const scannerRef = useRef(null);
  const scannerContainerId = "reader";

  // --- Scanner Control Functions ---
  const startScanner = () => {
    if (scannerRef.current) return;
    const scanner = new Html5QrcodeScanner(scannerContainerId, { fps: 10, qrbox: { width: 250, height: 250 } });
    scanner.render((decodedText) => {
      stopScanner();
      const herbId = extractHerbId(decodedText);
      if (herbId) fetchHerb(herbId);
    }, (error) => { /* Ignore scan failure */ });
    scannerRef.current = scanner;
    setIsScanning(true);
  };

  const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.clear().catch(err => console.error("Failed to clear scanner.", err));
      scannerRef.current = null;
      setIsScanning(false);
    }
  };

  // --- Data Fetching and Processing ---
  const fetchHerb = async (herbId) => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/herbs/${herbId}`);
      if (!res.ok) throw new Error("Failed to fetch herb details");
      const data = await res.json();
      if (!data.success) throw new Error(data.message || "Herb not found");
      let farmerName = "N/A";
      try {
        const farmerRes = await fetch(`${API}/users/${data.herb.farmer}`);
        if (farmerRes.ok) {
          const farmerData = await farmerRes.json();
          farmerName = farmerData?.user?.name || "N/A";
        }
      } catch (err) { console.warn("Could not fetch farmer name:", err); }
      setHerb({ ...data.herb, farmerName });
      setFormData({ ...data.herb, farmerName, transportCity: "", transportPincode: "", transportGeoLocation: { lat: "", long: "" }, driverName: "", vehicleNumber: "", transportQuantity: "" });
      setIsScannerActive(false);
    } catch (err) { // <<< FIXED: Added the opening curly brace here
      alert(`Error: ${err.message}`);
      setHerb(null);
    } finally {
      setLoading(false);
    }
  };

  const extractHerbId = (url) => {
    try {
      return new URL(url).pathname.split('/').filter(Boolean).pop();
    } catch (error) {
      const parts = url.split("/");
      return parts.pop() || parts.pop();
    }
  };

  // --- Event Handlers ---
  const handleLinkSubmit = (e) => {
    e.preventDefault();
    if (!link) return;
    const herbId = extractHerbId(link);
    if (herbId) fetchHerb(herbId);
    else alert("Invalid link provided.");
  };
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleLocationChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, transportGeoLocation: { ...prev.transportGeoLocation, [name]: value } }));
  };

  const handleGeolocation = useCallback(() => {
    if (!navigator.geolocation) {
      return alert('Geolocation is not supported by your browser.');
    }

    console.log("[1/5] Starting geolocation process...");
    setLoading(true);
    const options = { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 };
    
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        console.log(`[2/5] Successfully retrieved coordinates from browser:`, { latitude, longitude });

        try {
          const nominatimUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`;
          console.log(`[3/5] Fetching address details from: ${nominatimUrl}`);
          
          const geoRes = await fetch(nominatimUrl);
          const geoData = await geoRes.json();
          console.log(`[4/5] Received response from Nominatim API:`, geoData);

          const locationUpdate = {
            transportGeoLocation: { lat: latitude.toFixed(6), long: longitude.toFixed(6) },
            transportCity: geoData.address?.city || geoData.address?.town || geoData.address?.village || geoData.address?.city_district || geoData.address?.state_district || "",
            transportPincode: geoData.address?.postcode || "",
          };

          console.log(`[5/5] Updating form state with fetched data:`, locationUpdate);
          setFormData(prev => ({
            ...prev,
            ...locationUpdate,
          }));

        } catch (error) {
          console.error("Reverse geocoding error:", error);
          setFormData(prev => ({ ...prev, transportGeoLocation: { lat: latitude.toFixed(6), long: longitude.toFixed(6) } }));
          alert("Could not automatically fetch city and pincode. Please enter them manually.");
        } finally {
          setLoading(false);
        }
      },
      (error) => {
        setLoading(false);
        console.error("Browser geolocation error:", error);
        alert(`Could not get your location: ${error.message}. Please enter manually.`);
      },
      options
    );
  }, []);

  const handleTransportSubmit = async (e) => {
    e.preventDefault();
    const originalQty = Number(herb.quantity), transportQty = Number(formData.transportQuantity);
    const lowerBound = originalQty * 0.98, upperBound = originalQty * 1.02;
    if (transportQty < lowerBound || transportQty > upperBound) {
      alert(`Quantity must be between ${lowerBound.toFixed(2)} and ${upperBound.toFixed(2)} grams (±2%).`);
      return;
    }
    setLoading(true);
    const payload = {
      herbName: herb.herbName, date: herb.date, quantity: herb.quantity, geoLocation: herb.geoLocation, city: herb.city, address: herb.address, county: herb.county, pincode: herb.pincode, farmerId: herb.farmer, farmerName: herb.farmerName,
      transportCity: formData.transportCity, transportPincode: formData.transportPincode, transportGeoLocation: { lat: Number(formData.transportGeoLocation.lat), long: Number(formData.transportGeoLocation.long) },
      driverName: formData.driverName, vehicleNumber: formData.vehicleNumber, transportQuantity: Number(formData.transportQuantity),
    };
    try {
      const res = await fetch(`${API}/transport`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await res.json();
      if (data.success && data.transport?._id) {
        const transportId = data.transport._id;
        const qrPayload = `${window.location.origin}/transport/${transportId}`;
        const qrDataUrl = await QRCode.toDataURL(qrPayload);
        await fetch(`${API}/transport/${transportId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ qrPayload, qrImage: qrDataUrl }) });
        setQrImage(qrDataUrl);
        setQrLink(qrPayload);
        alert("Transport submitted and QR generated successfully!");
      } else {
        throw new Error(data.message || "Transport submission failed.");
      }
    } catch (err) {
      alert(`Failed to submit transport: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // --- Effects ---
  useEffect(() => {
    if (!isScannerActive && herb) {
      handleGeolocation();
    }
  }, [isScannerActive, herb, handleGeolocation]);

  useEffect(() => {
    return () => { if (scannerRef.current) stopScanner(); };
  }, []);

  return (
    <div className="flex flex-col items-center p-4 md:p-6 bg-gray-50 min-h-screen ">
      {isScannerActive ? (
        <div className="w-full max-w-lg  mx-auto text-center">
          <h1 className="text-3xl font-bold text-[#133215] mb-2">Scan Batch QR Code</h1>
          <p className="text-gray-600 mb-6">Press "Start Scanning" to open the camera.</p>
          <div id={scannerContainerId} className="w-full bg-white p-2 border border-white rounded-xl mb-4" />
          {!isScanning ? (
            <button onClick={startScanner} className="w-full px-6 py-3 bg-[#92B775] text-white font-semibold rounded-md hover:bg-[#82a365] transition-all">Start Scanning</button>
          ) : (
            <button onClick={stopScanner} className="w-full px-6 py-3 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 transition-all">Stop Scanning</button>
          )}
          <div className="flex items-center my-4">
            <hr className="flex-grow border-t border-gray-300" /><span className="px-4 text-gray-500 font-semibold">OR</span><hr className="flex-grow border-t border-gray-300" />
          </div>
          <form onSubmit={handleLinkSubmit} className="w-full flex gap-2">
            <input type="text" placeholder="Paste herb link here" value={link} onChange={(e) => setLink(e.target.value)} className="flex-1 border border-gray-300 px-4 py-2 rounded-md focus:ring-[#92B775] focus:border-[#92B775]" />
            <button type="submit" disabled={loading} className="bg-gray-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-gray-700 transition-all">{loading ? "..." : "Fetch"}</button>
          </form>
        </div>
      ) : herb && (
        <main className="w-full flex-grow container mx-auto">
          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-xl shadow-2xl">
            <h2 className="text-3xl font-bold text-[#133215] mb-2 text-center">Update Transport Details</h2>
            <p className="text-center text-gray-600 mb-8">Enter the details for the next stage of the supply chain.</p>
            <div className="mb-8 p-4 bg-green-50 border border-green-200 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Original Herb Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div><p className="font-medium text-gray-500">Herb Name</p><p className="text-gray-900 font-semibold">{herb.herbName}</p></div>
                <div><p className="font-medium text-gray-500">Farmer Name</p><p className="text-gray-900 font-semibold">{herb.farmerName}</p></div>
                <div><p className="font-medium text-gray-500">Harvest Date</p><p className="text-gray-900 font-semibold">{new Date(herb.date).toLocaleDateString()}</p></div>
              </div>
            </div>

            {user.role !== "farmer" && (
              <form onSubmit={handleTransportSubmit} className="space-y-8">
                <div className="border-t pt-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-gray-800">Transport Location</h3>
                    <button type="button" onClick={handleGeolocation} disabled={loading} className="px-3 py-1 text-xs font-semibold text-[#133215] bg-green-100 rounded-md hover:bg-green-200 transition">
                      {loading ? 'Fetching...' : 'Get Current Location'}
                    </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Latitude</label><StyledInput name="lat" type="number" value={formData.transportGeoLocation.lat} onChange={handleLocationChange} required /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Longitude</label><StyledInput name="long" type="number" value={formData.transportGeoLocation.long} onChange={handleLocationChange} required /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">City</label><StyledInput name="transportCity" value={formData.transportCity} onChange={handleChange} required /></div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Pincode</label><StyledInput name="transportPincode" value={formData.transportPincode} onChange={handleChange} required /></div>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Vehicle & Quantity</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="md:col-span-1"><label className="block text-sm font-medium text-gray-700 mb-1">Driver Name</label><StyledInput name="driverName" placeholder="e.g., Ramesh Kumar" value={formData.driverName} onChange={handleChange} required /></div>
                    <div className="md:col-span-1"><label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Number</label><StyledInput name="vehicleNumber" placeholder="e.g., MP09AB1234" value={formData.vehicleNumber} onChange={handleChange} required /></div>
                    <div className="md:col-span-1"><label className="block text-sm font-medium text-gray-700 mb-1">Quantity (grams)</label><StyledInput name="transportQuantity" type="number" placeholder="e.g., 5000" value={formData.transportQuantity} onChange={handleChange} required /></div>
                  </div>
                </div>

                <div className="text-center pt-6">
                  <button type="submit" disabled={loading} className="w-full md:w-auto px-12 py-3 bg-[#92B775] text-white font-bold text-lg rounded-lg hover:bg-[#82a365] transition-all duration-300 shadow-lg disabled:bg-gray-400">
                    {loading ? "Submitting..." : "Submit & Generate QR"}
                  </button>
                </div>
              </form>
            )}

            {qrImage && (
              <div className="mt-10 pt-6 border-t flex flex-col items-center gap-4">
                <h3 className="text-xl font-semibold text-[#133215]">New Transport QR Code</h3>
                <img src={qrImage} alt="Generated Transport QR Code" className="w-48 h-48 border p-1 rounded-md bg-white" />
                <a href={qrLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline hover:text-blue-800">Open Transport Link</a>
                <a href={qrImage} download={`transport-qr-${herb.herbName}.png`} className="px-4 py-2 bg-gray-700 text-white text-sm font-semibold rounded-md hover:bg-gray-800 transition-all">Download QR Code</a>
              </div>
            )}
          </div>
        </main>
      )}
    </div>
  );
};

export default ScanUpdateBatch;