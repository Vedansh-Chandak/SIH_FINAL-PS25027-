import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import SignupImage from '../assets/farmerimage2.jpg';

// Icons for social login buttons
const GoogleIcon = () => (
    <svg className="w-5 h-5" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039L38.802 6.5C34.522 2.763 29.632 0.5 24 0.5C10.745 0.5 0.5 10.745 0.5 24S10.745 47.5 24 47.5c13.033 0 22.99-9.605 22.99-22.99c0-1.593-0.14-3.15-0.389-4.427z"></path><path fill="#FF3D00" d="M6.306 14.691c-2.413 4.893-3.806 10.426-3.806 16.309C2.5 36.599 7.042 43.1 14.12 46.44c3.483-2.91 5.76-7.393 5.76-12.44s-2.277-9.53-5.76-12.44l-7.814-6.869z"></path><path fill="#4CAF50" d="M24 47.5c5.94 0 11.21-1.808 15.31-4.81l-6.55-5.43c-2.14 1.45-4.84 2.24-7.76 2.24c-5.22 0-9.65-3.34-11.3-7.91l-7.96 6.5C8.81 42.75 15.81 47.5 24 47.5z"></path><path fill="#1976D2" d="M43.611 20.083L43.59 20H24v8h11.303c-0.792 2.237-2.231 4.16-4.087 5.571l6.522 5.38c4.467-4.133 7.266-10.274 7.266-17.433c0-1.593-0.14-3.15-0.389-4.427z"></path></svg>
);
const AadhaarIcon = () => (
    <svg className="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 012-2h2a2 2 0 012 2v1m-6 0h6m-3 6.75a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5zM8 17h8a1 1 0 001-1v-1.5a1 1 0 00-1-1H8a1 1 0 00-1 1V16a1 1 0 001 1z"></path></svg>
);


const API = import.meta.env.VITE_API_BASE_URL;

const SignIn = ({ onSignIn }) => {
  const [verificationId, setVerificationId] = useState("");
  const [role, setRole] = useState("farmer");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = { verificationId };
      if (role !== "farmer") {
        payload.password = password;
      }

      const res = await fetch(`${API}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      console.log(data);
      
      if (res.ok) {
        alert(`✅ ${data.message}`);
        if(onSignIn) onSignIn(data.user); 
        navigate("/");
      } else {
        alert(`❌ ${data.error || "Login failed"}`);
      }
    } catch (err) {
      console.error("Login error:", err);
      alert("❌ Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-black/15 p-4 font-sans">
      <div className="w-full max-w-4xl mx-auto bg-white rounded-2xl shadow-xl grid lg:grid-cols-2">
        
        {/* --- Left Panel: Image --- */}
        <div className="hidden lg:block">
          <img
            src={SignupImage}
            alt="A farmer in a field"
            className="w-full h-[90vh] object-cover opacity-97 rounded-l-2xl"
          />
        </div>

        {/* --- Right Panel: Form --- */}
        <div className="p-8 flex flex-col justify-center">
          <div className="w-full max-w-sm mx-auto">
            
            <div className="text-right mb-4">
              <p className="text-sm text-gray-600">
                Need an account?{' '}
                <Link to="/signup" className="font-semibold text-[#133215] hover:underline">
                  Sign Up
                </Link>
              </p>
            </div>
            
            <h2 className="text-3xl font-bold text-[#133215] mb-2">Welcome Back!</h2>
            <p className="text-gray-600 mb-6">Sign in to continue to your dashboard.</p>
{/* 
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
                <button type="button" className="w-full flex items-center justify-center gap-2 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                   <GoogleIcon />
                   <span className="font-medium text-gray-700 text-sm">Sign in with Google</span>
                </button>
                <button type="button" className="w-full flex items-center justify-center gap-2 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                   <AadhaarIcon />
                   <span className="font-medium text-gray-700 text-sm">Sign in with Aadhaar</span>
                </button>
            </div> */}
            
            {/* <div className="flex items-center my-6">
              <hr className="flex-grow border-gray-200" />
              <span className="px-3 text-xs text-gray-500 uppercase">Or</span>
              <hr className="flex-grow border-gray-200" />
            </div> */}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label htmlFor="verificationId" className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                <input
                  id="verificationId"
                  type="text"
                  placeholder="Enter your Phone Number"
                  value={verificationId}
                  onChange={(e) => setVerificationId(e.target.value)}
                  required
                  className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-[#92B775] focus:border-[#92B775]"
                />
              </div>
              {/* <div>
                <p className="opacity-40">
                  (use PhoneNumber = 7974200013 
                  for farmer login)
                </p>
              </div> */}

              <div>
                <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">Your Role</label>
                <select
                  id="role"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md shadow-sm capitalize focus:ring-[#92B775] focus:border-[#92B775]"
                >
                  <option value="farmer">Farmer</option>
                  <option value="transporter">Transporter</option>
                  <option value="processor">Processor</option>
                  <option value="lab">Lab</option>
                  <option value="manufacturer">Manufacturer</option>
                </select>
              </div>

              {role !== "farmer" && (
                <div>
                  <label htmlFor="password"className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                  <input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-[#92B775] focus:border-[#92B775]"
                  />
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 px-4 bg-[#92B775] text-white font-semibold rounded-lg hover:bg-[#82a365] transition-colors duration-300 shadow-md disabled:bg-gray-400 disabled:cursor-not-allowed flex justify-center items-center"
                >
                  {loading ? (
                    <svg className="animate-spin h-5 w-5 text-white mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                  ) : null}
                  {loading ? "Signing In..." : "Sign In"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignIn;