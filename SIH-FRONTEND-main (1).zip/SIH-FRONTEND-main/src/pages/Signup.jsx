import React, { useState } from "react";

const API = "https://sih-backendfinal.onrender.com/api/users/register";
const OCR_API = "https://relievingly-bakerlike-dillon.ngrok-free.dev/extract-fields"; // your OCR URL

const Signup = () => {
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    dob: "",
    age: "",
    region: "",
    phoneNumber: "",
    verificationId: "",
    role: "",
    gender: "",
  });

  const roles = ["farmer", "transporter", "processor", "manufacturer"];
  const genders = ["male", "female", "other"];

  const calculateAge = (dobString) => {
    if (!dobString) return "";
    const birth = new Date(dobString);
    const ageDif = Date.now() - birth.getTime();
    return Math.abs(new Date(ageDif).getUTCFullYear() - 1970);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
      ...(name === "dob" ? { age: calculateAge(value) } : {})
    }));
  };

  const uploadCard = async(e)=>{
    const file = e.target.files[0];
    const fd = new FormData();
    fd.append("file", file);

    try{
      setLoading(true);

      const res = await fetch(OCR_API,{
        method:"POST",
        body:fd
      });

      const data = await res.json();
      console.log("OCR response",data);

      setFormData(prev => ({
        ...prev,
        name:data.extracted_name,
        dob:data.extracted_dob,
        region:data.extracted_address,
        verificationId:data.extracted_aadhaar || data.extracted_id,
        age:calculateAge(data.extracted_dob)
      }));

      setShowForm(true);

    }catch{
      alert("OCR failed");
    }finally{
      setLoading(false);
    }
  };

  const submit = async(e)=>{
    e.preventDefault();

    const payload = {
      name:formData.name,
      age:Number(formData.age),
      region:formData.region,
      phoneNumber:formData.phoneNumber,
      verificationId:formData.verificationId,
      role:formData.role,
      gender:formData.gender
    };

    console.log("final payload",payload);

    try{
      const res = await fetch(API,{
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body:JSON.stringify(payload)
      });

      const data = await res.json();
      console.log(data);

      if(res.ok){
        alert("Signup successful!");
      }else{
        alert(data.message);
      }

    }catch(err){
      alert("Network error");
    }
  };

  return(
    <div className="p-4">

      {!showForm && (
        <label>
          <input type="file" hidden onChange={uploadCard}/>
          <div className="p-3 bg-green-600 text-white rounded text-center cursor-pointer">
            Upload Aadhaar
          </div>
        </label>
      )}

      {loading && <h3>Extracting...</h3>}

      {!loading && showForm && (
        <form onSubmit={submit} className="space-y-2">

          <input value={formData.name} name="name"
            onChange={handleChange} placeholder="Name" className="border p-2 w-full"/>

          <input value={formData.dob} name="dob"
            onChange={handleChange} placeholder="DOB" className="border p-2 w-full"/>

          <input value={formData.age} disabled
            placeholder="Age" className="border p-2 w-full"/>

          <input value={formData.region} name="region"
            onChange={handleChange} placeholder="Region" className="border p-2 w-full"/>

          <input value={formData.phoneNumber} name="phoneNumber"
            onChange={handleChange} placeholder="Phone Number" className="border p-2 w-full"/>

          <input value={formData.verificationId} name="verificationId"
            onChange={handleChange} placeholder="Verification ID" className="border p-2 w-full"/>

          <select name="role" onChange={handleChange}
            className="border p-2 w-full" value={formData.role}>
            <option value="">Select Role</option>
            {roles.map(r => <option key={r}>{r}</option>)}
          </select>

          <select name="gender" onChange={handleChange}
            className="border p-2 w-full" value={formData.gender}>
            <option value="">Select Gender</option>
            {genders.map(g => <option key={g}>{g}</option>)}
          </select>

          <button className="w-full bg-green-600 text-white py-2 rounded">
            Register
          </button>
        </form>
      )}
    </div>
  )
};

export default Signup;
