import React from 'react';
import UploadHerbDataForm from '../components/herbForm';

const UploadHerbData = ({ user }) => {
  console.log(user);
  
  return (
    <div className=''>
      <UploadHerbDataForm user={user} />
    </div>
  );
};

export default UploadHerbData;
