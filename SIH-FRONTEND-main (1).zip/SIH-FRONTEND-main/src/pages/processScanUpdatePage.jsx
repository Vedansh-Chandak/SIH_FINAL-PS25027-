import React, { useEffect, useState, useRef } from "react";
import { Html5QrcodeScanner } from "html5-qrcode";
import QRCode from "qrcode";

// --- Environment Variables ---
const API = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";
const PROCESS_FIELDS = ["Cleaning", "Drying", "Powdering", "Packaging"];

// --- Reusable UI Components ---
const StyledInput = ({ name, id, type = "text", value, onChange, placeholder, required, readOnly = false }) => (
  <input
    type={type}
    name={name}
    id={id}
    value={value}
    onChange={onChange}
    placeholder={placeholder}
    required={required}
    readOnly={readOnly}
    className={`w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-[#92B775] focus:border-[#92B775] ${readOnly ? 'bg-gray-100 cursor-not-allowed' : ''}`}
  />
);

const ProcessScanUpdateBatch = ({ user }) => {
  const [transport, setTransport] = useState(null);
  const [link, setLink] = useState("");
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(false);
  const [qrImage, setQrImage] = useState("");
  const [qrLink, setQrLink] = useState("");
  
  // --- State for Scanner Control ---
  const [isScannerVisible, setIsScannerVisible] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const scannerRef = useRef(null);
  const scannerContainerId = "reader";

  // --- Scanner Control Functions ---
  const startScanner = () => {
    if (scannerRef.current) return;

    const scanner = new Html5QrcodeScanner(scannerContainerId, {
      fps: 10,
      qrbox: { width: 250, height: 250 },
    });

    const onScanSuccess = (decodedText) => {
        stopScanner();
        if (decodedText.includes("/transport/")) {
            const transportId = extractTransportId(decodedText);
            if (transportId) fetchTransport(transportId);
        } else {
            alert("Invalid QR Code: Please scan a valid transport QR code.");
        }
    };

    scanner.render(onScanSuccess, () => {});
    scannerRef.current = scanner;
    setIsScanning(true);
  };

  const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.clear()
        .then(() => {
          scannerRef.current = null;
          setIsScanning(false);
        })
        .catch(err => {
          console.error("Failed to clear scanner.", err);
          scannerRef.current = null;
          setIsScanning(false);
        });
    }
  };


  // --- Data Fetching ---
  const fetchTransport = async (transportId) => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/transport/${transportId}`);
      if (!res.ok) throw new Error("Failed to fetch transport details");
      const data = await res.json();
      if (!data.success) throw new Error(data.message || "Transport not found");

      setTransport(data.transport);
      setFormData({
        ...data.transport,
        processingUnitName: "",
        processes: [],
      });
      setIsScannerVisible(false); // Hide scanner view, show form
    } catch (err) {
      alert(`Error: ${err.message}`);
      setTransport(null);
    } finally {
      setLoading(false);
    }
  };

  const extractTransportId = (url) => {
    const parts = url.split("/");
    return parts.pop() || parts.pop();
  };

  // --- Event Handlers ---
  const handleLinkSubmit = (e) => {
    e.preventDefault();
    if (!link) return;
    const transportId = extractTransportId(link);
    if (transportId) fetchTransport(transportId);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox" && name === "processes") {
      setFormData((prev) => ({
        ...prev,
        processes: checked
          ? [...(prev.processes || []), value]
          : prev.processes.filter((p) => p !== value),
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleProcessingSubmit = async (e) => {
    e.preventDefault();
    if (!formData.processingUnitName || formData.processes.length === 0) {
        alert("Please enter the Processing Unit Name and select at least one process.");
        return;
    }
    setLoading(true);
    try {
      // Ensure numeric fields are correctly formatted
      const payload = {
        ...formData,
        quantity: Number(formData.quantity),
        transportQuantity: Number(formData.transportQuantity),
        geoLocation: {
          lat: Number(formData.geoLocation.lat),
          long: Number(formData.geoLocation.long),
        },
        transportGeoLocation: {
          lat: Number(formData.transportGeoLocation.lat),
          long: Number(formData.transportGeoLocation.long),
        },
      };

      const res = await fetch(`${API}/processing`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success && data.processing?._id) {
        const processingId = data.processing._id;
        const qrPayload = `${window.location.origin}/processing/${processingId}`;
        const qrDataUrl = await QRCode.toDataURL(qrPayload);

        await fetch(`${API}/processing/${processingId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ qrPayload, qrImage: qrDataUrl }),
        });

        setQrImage(qrDataUrl);
        setQrLink(qrPayload);
        alert("Processing submitted successfully!");
      } else {
        throw new Error(data.message || "Submission failed.");
      }
    } catch (err) {
      alert(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // --- Effect for cleanup ---
  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        stopScanner();
      }
    };
  }, []);
  
  if (user.role !== "processor") {
      return (
        <div className="text-center p-10">
            <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
            <p>You do not have permission to view this page.</p>
        </div>
      );
  }

  return (
    <div className="flex flex-col items-center p-4 md:p-6 bg-gray-50 min-h-screen">
      {isScannerVisible ? (
        <div className="w-full max-w-lg mx-auto text-center">
          <h1 className="text-3xl font-bold text-[#133215] mb-2">Scan Transport QR Code</h1>
          <p className="text-gray-600 mb-6">Press "Start Scanning" to open the camera.</p>
          
          <div id={scannerContainerId} className="w-full bg-white p-2  rounded-xl  mb-4" />
          
          {!isScanning ? (
            <button onClick={startScanner} className="w-full px-6 py-3 bg-[#92B775] text-white font-semibold rounded-md hover:bg-[#82a365] transition-all">
              Start Scanning
            </button>
          ) : (
            <button onClick={stopScanner} className="w-full px-6 py-3 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 transition-all">
              Stop Scanning
            </button>
          )}
          
          <div className="flex items-center my-4"><hr className="flex-grow"/><span className="px-4 text-gray-500">OR</span><hr className="flex-grow"/></div>

          <form onSubmit={handleLinkSubmit} className="w-full flex gap-2">
            <input
              type="text"
              placeholder="Paste transport link here"
              value={link}
              onChange={(e) => setLink(e.target.value)}
              className="flex-1 border border-gray-300 px-4 py-2 rounded-md focus:ring-[#92B775] focus:border-[#92B775]"
            />
            <button type="submit" disabled={loading} className="bg-gray-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-gray-700">
              {loading ? "..." : "Fetch"}
            </button>
          </form>
        </div>
      ) : transport && (
        <main className="w-full flex-grow container mx-auto">
          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-xl shadow-2xl">
            <h2 className="text-3xl font-bold text-[#133215] mb-2 text-center">Update Processing Details</h2>
            <p className="text-center text-gray-600 mb-8">Enter the processing information for the received batch.</p>

            {/* Read-only details section */}
            <div className="mb-8 p-4  bg-green-50 border border-green-200 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Original Transport Details</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div><p className="font-medium text-gray-500">Herb Name</p><p className="font-semibold">{transport.herbName}</p></div>
                <div><p className="font-medium text-gray-500">Farmer</p><p className="font-semibold">{transport.farmerName}</p></div>
                <div><p className="font-medium text-gray-500">Driver</p><p className="font-semibold">{transport.driverName}</p></div>
                <div><p className="font-medium text-gray-500">Vehicle</p><p className="font-semibold">{transport.vehicleNumber}</p></div>
                <div><p className="font-medium text-gray-500">Transport City</p><p className="font-semibold">{transport.transportCity}</p></div>
                <div><p className="font-medium text-gray-500">Quantity (g)</p><p className="font-semibold">{transport.transportQuantity}</p></div>
              </div>
            </div>

            {/* Processing form section */}
            <form onSubmit={handleProcessingSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2 border-t pt-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Processing Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Processing Unit Name</label>
                    <StyledInput name="processingUnitName" placeholder="e.g., Jabalpur Processing Center" value={formData.processingUnitName} onChange={handleChange} required />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Processes Applied</label>
                    <div className="grid grid-cols-2 gap-4 p-4 border rounded-md bg-gray-50">
                      {PROCESS_FIELDS.map((p) => (
                        <label key={p} className="flex items-center gap-3 cursor-pointer">
                          <input type="checkbox" name="processes" value={p} checked={formData.processes?.includes(p)} onChange={handleChange} className="h-4 w-4 rounded border-gray-300 text-green-600 focus:ring-green-500"/>
                          <span className="text-gray-800">{p}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="md:col-span-2 text-center mt-6">
                <button type="submit" disabled={loading || qrImage} className="w-full md:w-auto px-12 py-3 bg-[#92B775] text-white font-bold text-lg rounded-lg hover:bg-[#82a365] transition-all duration-300 shadow-lg disabled:bg-gray-400 disabled:cursor-not-allowed">
                  {loading ? "Submitting..." : "Submit & Generate QR"}
                </button>
              </div>
            </form>

            {qrImage && (
              <div className="mt-10 pt-6 border-t flex flex-col items-center gap-4">
                <h3 className="text-xl font-semibold text-[#133215]">New Processing QR Code</h3>
                <img src={qrImage} alt="Generated Processing QR Code" className="w-48 h-48 border p-1 rounded-md bg-white" />
                <a href={qrLink} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline hover:text-blue-800">Open Processing Link</a>
                <a href={qrImage} download={`processing-qr-${transport.herbName}.png`} className="px-4 py-2 bg-gray-700 text-white text-sm font-semibold rounded-md hover:bg-gray-800">Download QR Code</a>
              </div>
            )}
          </div>
        </main>
      )}
    </div>
  );
};

export default ProcessScanUpdateBatch;