// utils/db.js
import { openDB } from "idb";

export const initDB = async () => {
  return openDB("herbDB", 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains("herbs")) {
        db.createObjectStore("herbs", { keyPath: "id", autoIncrement: true });
      }
    },
  });
};

export const saveOfflineHerb = async (herbData) => {
  const db = await initDB();
  await db.add("herbs", herbData);
  console.log("📦 Saved offline herb:", herbData);
};

export const getOfflineHerbs = async () => {
  const db = await initDB();
  return await db.getAll("herbs");
};

export const clearOfflineHerbs = async () => {
  const db = await initDB();
  await db.clear("herbs");
  console.log("🗑️ Cleared offline herbs after sync");
};
