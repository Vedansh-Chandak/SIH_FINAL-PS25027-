// utils/geocode.js
export async function getAddressFromCoords(latitude, longitude) {
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`
    );
    if (!res.ok) throw new Error("Failed to fetch address");
    const data = await res.json();

    return {
      city: data.address.city || data.address.town || data.address.village || "",
      state: data.address.state || "",
      country: data.address.country || "",
      pincode: data.address.postcode || "",
      fullAddress: data.display_name || "",
    };
  } catch (err) {
    console.error("❌ Reverse geocoding failed:", err);
    return null;
  }
}
