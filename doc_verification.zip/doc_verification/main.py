import os
import tempfile
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from ocr.extract import extract_clean_lines
from ocr.parser import extract_structured_fields

app = FastAPI(title="Document Verifier API")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ALLOWED_EXT = {"png", "jpg", "jpeg"}

# ---------- HOME ROUTE ----------
@app.get("/")
async def home():
    return {"message": "Document Verifier API is working 🚀"}
# --------------------------------


def save_upload_tmp(upload_file: UploadFile) -> str:
    suffix = os.path.splitext(upload_file.filename)[1]
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(upload_file.file.read())
        tmp.flush()
    finally:
        tmp.close()
    return tmp.name


# ---------- EXTRACT FIELDS ENDPOINT ----------
@app.post("/extract-fields")
async def extract_fields(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")

    ext = file.filename.split(".")[-1].lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(status_code=400, detail="Unsupported file type")

    tmp_path = save_upload_tmp(file)

    try:
        # OCR text processing
        lines = extract_clean_lines(tmp_path)

        # Extract name, dob, address
        doc_fields = extract_structured_fields(lines)

        # Only return these 3 fields
        response = {
            "extracted_name": doc_fields.get("name", ""),
            "extracted_dob": doc_fields.get("dob", ""),
            "extracted_address": doc_fields.get("address", "")
        }

        return JSONResponse(content=response)

    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
# ------------------------------------------------
