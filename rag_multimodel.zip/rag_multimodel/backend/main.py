# backend/main.py

import os
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from backend.rag.generator import get_rag_qa

load_dotenv()

app = FastAPI()

# Allow frontend (React/Vue/HTML) to connect later
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],        # change this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

print("🚀 Initializing RAG backend...")
qa_chain = get_rag_qa()    # load ONCE to avoid reload delays

# In-memory storage for conversation memory
chat_sessions = {}

# Request schema
class Query(BaseModel):
    session_id: str     # unique ID from frontend
    question: str       # user question


@app.post("/ask")
async def ask_question(query: Query):
    """RAG chatbot endpoint with memory support"""
    try:
        print("💬 User Query:", query.question)

        # Load memory for this user session
        session = chat_sessions.get(query.session_id, [])

        # Add new user message
        session.append({"role": "user", "content": query.question})

        # Build conversation context
        conversation_context = ""
        for msg in session:
            role = "User" if msg["role"] == "user" else "Assistant"
            conversation_context += f"{role}: {msg['content']}\n"

        # Prepare RAG query with memory
        final_input = {"query": f"{conversation_context}\nAssistant:"}

        # Perform RAG
        response = qa_chain(final_input)
        answer = response["result"]

        # Add bot reply to memory
        session.append({"role": "assistant", "content": answer})
        chat_sessions[query.session_id] = session  # save memory

        # Return sources
        sources = [
            {
                "file": doc.metadata.get("source", "unknown"),
                "content": doc.page_content[:300] + "..."
            }
            for doc in response["source_documents"]
        ]

        return {"answer": answer, "sources": sources}

    except Exception as e:
        print("❌ Error:", e)
        return {"error": str(e)}


@app.get("/")
def root():
    return {"message": "RAG Chatbot Backend Running!"}
