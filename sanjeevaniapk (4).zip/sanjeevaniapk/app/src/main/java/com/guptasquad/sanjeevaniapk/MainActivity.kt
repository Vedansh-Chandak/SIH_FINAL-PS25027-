package com.guptasquad.sanjeevaniapk

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.CookieManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.app.ActivityCompat

@Suppress("SetJavaScriptEnabled")
class MainActivity : ComponentActivity() {

    private val requiredPermissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        // switch from the native splash theme to the app runtime theme (ensure this style exists)
        setTheme(R.style.Theme_Sanjeevani)
        super.onCreate(savedInstanceState)

        // disable WebView remote debugging for release-like behaviour
        WebView.setWebContentsDebuggingEnabled(false)

        // permission launcher
        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { /* result ignored (optional: handle if needed) */ }

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    // Load the signup/login URL first (user requested)
                    val loginUrl = "https://sih-frontend-lyart.vercel.app/signup"

                    PolishedWebViewScreen(
                        url = loginUrl,
                        onRequestPermissions = { permissionLauncher.launch(requiredPermissions) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PolishedWebViewScreen(
    url: String,
    onRequestPermissions: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    var webView by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableStateOf(true) }
    var pageError by remember { mutableStateOf<String?>(null) }

    // minimal splash: ensure the splash is visible at least briefly
    val minSplashMs = 700L
    var splashVisible by remember { mutableStateOf(true) }
    var splashStart by remember { mutableStateOf(0L) }
    LaunchedEffect(loading) {
        if (loading) {
            splashVisible = true
            splashStart = System.currentTimeMillis()
        } else {
            val elapsed = System.currentTimeMillis() - splashStart
            val remain = (minSplashMs - elapsed).coerceAtLeast(0L)
            if (remain > 0) kotlinx.coroutines.delay(remain)
            splashVisible = false
        }
    }

    val alphaAnim by animateFloatAsState(targetValue = if (splashVisible) 0f else 1f, animationSpec = tween(360))

    // Request permissions at startup (non-blocking)
    LaunchedEffect(Unit) {
        val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val audioGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val locGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!cameraGranted || !audioGranted || !locGranted) onRequestPermissions()
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // WebView container
        AndroidView(factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                settings.mediaPlaybackRequiresUserGesture = false
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false

                // Append a small identifier to the UA so backend can detect app traffic
                settings.userAgentString = settings.userAgentString + " SanjeevaniApp/1.0"

                // cookies
                val cookieManager = CookieManager.getInstance()
                cookieManager.setAcceptCookie(true)
                cookieManager.setAcceptThirdPartyCookies(this, true)

                overScrollMode = WebView.OVER_SCROLL_NEVER

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        loading = true
                        pageError = null
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        loading = false
                    }

                    override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                        if (request?.isForMainFrame == true) {
                            pageError = error?.description?.toString() ?: "Unknown error"
                            loading = false
                        }
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onPermissionRequest(request: PermissionRequest) {
                        activity?.runOnUiThread {
                            val grants = request.resources.filter { res ->
                                when (res) {
                                    PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

                                    PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

                                    else -> true
                                }
                            }.toTypedArray()

                            if (grants.isNotEmpty()) request.grant(grants) else request.deny()
                        }
                    }

                    override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (granted) callback?.invoke(origin, true, false) else {
                            activity?.let { ActivityCompat.requestPermissions(it, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 201) }
                            callback?.invoke(origin, false, false)
                        }
                    }
                }

                webView = this
                loadUrl(url) // load login/signup URL first
            }
        }, update = { view -> webView = view })

        // offline / error overlay
        if (pageError != null) {
            Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f), modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(text = "Connection problem", style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = pageError ?: "Network error. Please check internet.", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(onClick = { pageError = null; webView?.reload() }) { Text("Retry") }
                }
            }
        }

        // fade-in animation (applies to WebView content visually)
        Box(modifier = Modifier.matchParentSize().graphicsLayer { alpha = alphaAnim })

        // splash overlay
        if (splashVisible) {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primary) {
                Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    // uses generated launcher foreground; safe fallback to mipmap if not found
                    Image(painter = painterResource(id = R.mipmap.ic_launcher_foreground), contentDescription = "App logo", modifier = Modifier.size(110.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Sanjeevani", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
    }

    // back action: go back in web history, else finish
    BackHandler {
        if (webView?.canGoBack() == true) webView?.goBack() else activity?.finish()
    }
}